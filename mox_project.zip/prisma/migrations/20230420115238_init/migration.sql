-- CreateEnum
CREATE TYPE "RoleName" AS ENUM ('SUPER_ADMIN', 'ADMIN', 'NORMAL_USER');

-- AlterTable
ALTER TABLE "UserAccount" ADD COLUMN     "role_name" "RoleName" NOT NULL DEFAULT 'NORMAL_USER';
