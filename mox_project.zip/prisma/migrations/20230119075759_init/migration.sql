-- AlterTable
ALTER TABLE "campaign" ADD COLUMN     "category" JSONB,
ADD COLUMN     "mau" TEXT;
