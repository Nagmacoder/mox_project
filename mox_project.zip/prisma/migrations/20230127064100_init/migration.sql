/*
  Warnings:

  - You are about to drop the `audience_fields` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `campaign_fields` table. If the table is not empty, all the data it contains will be lost.
  - Added the required column `age_range_max` to the `audience` table without a default value. This is not possible if the table is not empty.
  - Added the required column `age_range_min` to the `audience` table without a default value. This is not possible if the table is not empty.
  - Added the required column `audience_group` to the `audience` table without a default value. This is not possible if the table is not empty.
  - Added the required column `campaign_name` to the `campaign` table without a default value. This is not possible if the table is not empty.
  - Added the required column `end_duration` to the `campaign` table without a default value. This is not possible if the table is not empty.
  - Added the required column `start_duration` to the `campaign` table without a default value. This is not possible if the table is not empty.
  - Added the required column `volume` to the `campaign` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "audience_fields" DROP CONSTRAINT "audience_fields_audience_id_fkey";

-- DropForeignKey
ALTER TABLE "campaign_fields" DROP CONSTRAINT "campaign_fields_campaign_id_fkey";

-- AlterTable
ALTER TABLE "audience" ADD COLUMN     "age_range_max" VARCHAR(255) NOT NULL,
ADD COLUMN     "age_range_min" VARCHAR(255) NOT NULL,
ADD COLUMN     "approx_mau" TEXT,
ADD COLUMN     "arpu" TEXT,
ADD COLUMN     "audience_category" JSONB,
ADD COLUMN     "audience_group" VARCHAR(255) NOT NULL,
ADD COLUMN     "audience_location" JSONB,
ADD COLUMN     "gender" JSONB,
ADD COLUMN     "languages" JSONB;

-- AlterTable
ALTER TABLE "campaign" ADD COLUMN     "about" TEXT,
ADD COLUMN     "budget_max" TEXT,
ADD COLUMN     "budget_min" TEXT,
ADD COLUMN     "campaign_name" VARCHAR(255) NOT NULL,
ADD COLUMN     "category" JSONB,
ADD COLUMN     "conversion_type" TEXT,
ADD COLUMN     "creatives" JSONB,
ADD COLUMN     "destination_url" TEXT,
ADD COLUMN     "end_duration" TIMESTAMP(3) NOT NULL,
ADD COLUMN     "mau" TEXT,
ADD COLUMN     "payout_percent" TEXT,
ADD COLUMN     "payout_terms" TEXT,
ADD COLUMN     "start_duration" TIMESTAMP(3) NOT NULL,
ADD COLUMN     "trial_period" TEXT,
ADD COLUMN     "volume" VARCHAR(255) NOT NULL;

-- DropTable
DROP TABLE "audience_fields";

-- DropTable
DROP TABLE "campaign_fields";
