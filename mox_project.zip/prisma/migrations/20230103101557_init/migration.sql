-- DropIndex
DROP INDEX "brand_business_entity_id_key";
