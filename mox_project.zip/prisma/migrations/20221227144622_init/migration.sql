/*
  Warnings:

  - You are about to drop the column `country` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `user_interests` on the `audience` table. All the data in the column will be lost.
  - The `languages` column on the `audience` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `social_media_preferences` column on the `audience` table would be dropped and recreated. This will lead to data loss if there is data in the column.

*/
-- AlterTable
ALTER TABLE "audience" DROP COLUMN "country",
DROP COLUMN "user_interests",
ADD COLUMN     "audience_category" JSONB,
ADD COLUMN     "audience_location" JSONB,
DROP COLUMN "languages",
ADD COLUMN     "languages" JSONB,
DROP COLUMN "social_media_preferences",
ADD COLUMN     "social_media_preferences" JSONB;

-- CreateTable
CREATE TABLE "campaign" (
    "campaign_id" SERIAL NOT NULL,
    "campaign_name" VARCHAR(255) NOT NULL,
    "brand_id" INTEGER NOT NULL,
    "audience_id" INTEGER NOT NULL,
    "about" TEXT,
    "destination_url" TEXT,
    "start_duration" TIMESTAMP(3) NOT NULL,
    "end_duration" TIMESTAMP(3) NOT NULL,
    "volume" VARCHAR(255) NOT NULL,
    "budget_min" TEXT,
    "budget_max" TEXT,
    "conversion_type" TEXT,
    "payout_percent" TEXT,
    "payout_terms" TEXT,
    "trial_period" TEXT,
    "creatives" JSONB,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "campaign_pkey" PRIMARY KEY ("campaign_id")
);

-- AddForeignKey
ALTER TABLE "campaign" ADD CONSTRAINT "campaign_brand_id_fkey" FOREIGN KEY ("brand_id") REFERENCES "brand"("brand_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "campaign" ADD CONSTRAINT "campaign_audience_id_fkey" FOREIGN KEY ("audience_id") REFERENCES "audience"("audience_id") ON DELETE RESTRICT ON UPDATE CASCADE;
