-- CreateEnum
CREATE TYPE "RequestStatus" AS ENUM ('REQUESTED', 'ACCEPTED', 'REJECTED', 'CANCELLED');

-- AlterTable
ALTER TABLE "ConnectionRequest" ADD COLUMN     "requestStatus" "RequestStatus" NOT NULL DEFAULT 'REQUESTED';
