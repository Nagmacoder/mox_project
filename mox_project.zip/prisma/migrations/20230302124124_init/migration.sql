-- CreateTable
CREATE TABLE "BusinessCategories" (
    "business_category_id" SERIAL NOT NULL,
    "business_category_name" VARCHAR(255) NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "BusinessCategories_pkey" PRIMARY KEY ("business_category_id")
);

-- CreateTable
CREATE TABLE "CountriesData" (
    "country_id" SERIAL NOT NULL,
    "country_name" VARCHAR(255) NOT NULL,
    "country_code" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CountriesData_pkey" PRIMARY KEY ("country_id")
);
