/*
  Warnings:

  - You are about to drop the column `facebook` on the `brand_profile` table. All the data in the column will be lost.
  - You are about to drop the column `instagram` on the `brand_profile` table. All the data in the column will be lost.
  - You are about to drop the column `tiktok` on the `brand_profile` table. All the data in the column will be lost.
  - You are about to drop the column `twitter` on the `brand_profile` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "brand_profile" DROP COLUMN "facebook",
DROP COLUMN "instagram",
DROP COLUMN "tiktok",
DROP COLUMN "twitter",
ADD COLUMN     "social_media_handles" JSONB;
