-- CreateTable
CREATE TABLE "brand" (
    "brand_id" SERIAL NOT NULL,
    "user_id" INTEGER NOT NULL,
    "brand_name" VARCHAR(255) NOT NULL,
    "category" VARCHAR(255) NOT NULL,
    "website" VARCHAR(255) NOT NULL,

    CONSTRAINT "brand_pkey" PRIMARY KEY ("brand_id")
);

-- CreateTable
CREATE TABLE "brand_profile" (
    "brand_profile_id" SERIAL NOT NULL,
    "brand_id" INTEGER NOT NULL,
    "logo" VARCHAR(255) NOT NULL,
    "profile_background" TEXT,
    "lead_statement" TEXT,
    "about" TEXT,
    "business_location" JSONB,
    "industry_types" JSONB,
    "partnership_types" JSONB,
    "store" TEXT,
    "website" TEXT,
    "twitter" TEXT,
    "facebook" TEXT,
    "instagram" TEXT,
    "tiktok" TEXT,

    CONSTRAINT "brand_profile_pkey" PRIMARY KEY ("brand_profile_id")
);

-- CreateTable
CREATE TABLE "audience" (
    "audience_id" SERIAL NOT NULL,
    "brand_id" INTEGER NOT NULL,
    "audience_name" VARCHAR(255) NOT NULL,
    "audience_type" VARCHAR(255) NOT NULL,
    "age_range_min" VARCHAR(255) NOT NULL,
    "age_range_max" VARCHAR(255) NOT NULL,
    "gender_type" VARCHAR(255) NOT NULL,
    "approx_total" VARCHAR(255) NOT NULL,
    "psychographics" VARCHAR(255) NOT NULL,
    "user_interests" TEXT,
    "languages" TEXT,
    "occupation" TEXT,
    "annual_income" TEXT,
    "avg_spent_per_cart_min" TEXT,
    "avg_spent_per_cart_max" TEXT,
    "social_media_preferences" TEXT,

    CONSTRAINT "audience_pkey" PRIMARY KEY ("audience_id")
);

-- CreateTable
CREATE TABLE "location" (
    "location_id" SERIAL NOT NULL,
    "location_name" VARCHAR(255) NOT NULL,

    CONSTRAINT "location_pkey" PRIMARY KEY ("location_id")
);

-- CreateIndex
CREATE UNIQUE INDEX "brand_user_id_key" ON "brand"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "brand_profile_brand_id_key" ON "brand_profile"("brand_id");

-- AddForeignKey
ALTER TABLE "brand" ADD CONSTRAINT "brand_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "UserAccount"("user_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "brand_profile" ADD CONSTRAINT "brand_profile_brand_id_fkey" FOREIGN KEY ("brand_id") REFERENCES "brand"("brand_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "audience" ADD CONSTRAINT "audience_brand_id_fkey" FOREIGN KEY ("brand_id") REFERENCES "brand"("brand_id") ON DELETE RESTRICT ON UPDATE CASCADE;
