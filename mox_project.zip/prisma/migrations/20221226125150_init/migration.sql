-- AlterTable
ALTER TABLE "audience" ADD COLUMN     "country" JSONB;
