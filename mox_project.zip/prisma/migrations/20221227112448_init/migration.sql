/*
  Warnings:

  - The values [DATA_CONSUMER,DATA_PROVIDER] on the enum `BusinessEntityTypeName` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterEnum
BEGIN;
CREATE TYPE "BusinessEntityTypeName_new" AS ENUM ('PROMOTION_PARTNER', 'MONETIZATION_PARTNER', 'BOTH');
ALTER TABLE "BusinessEntityType" ALTER COLUMN "business_entity_type_name" DROP DEFAULT;
ALTER TABLE "BusinessEntityType" ALTER COLUMN "business_entity_type_name" TYPE "BusinessEntityTypeName_new" USING ("business_entity_type_name"::text::"BusinessEntityTypeName_new");
ALTER TYPE "BusinessEntityTypeName" RENAME TO "BusinessEntityTypeName_old";
ALTER TYPE "BusinessEntityTypeName_new" RENAME TO "BusinessEntityTypeName";
DROP TYPE "BusinessEntityTypeName_old";
ALTER TABLE "BusinessEntityType" ALTER COLUMN "business_entity_type_name" SET DEFAULT 'BOTH';
COMMIT;
