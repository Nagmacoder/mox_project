/*
  Warnings:

  - You are about to drop the column `category` on the `brand` table. All the data in the column will be lost.
  - You are about to drop the `brand_profile` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "brand_profile" DROP CONSTRAINT "brand_profile_brand_id_fkey";

-- AlterTable
ALTER TABLE "brand" DROP COLUMN "category",
ADD COLUMN     "about" TEXT,
ADD COLUMN     "audience_location" JSONB,
ADD COLUMN     "languages" JSONB,
ADD COLUMN     "logo" TEXT,
ADD COLUMN     "mau" TEXT,
ADD COLUMN     "online_store" TEXT,
ADD COLUMN     "site_category" TEXT,
ADD COLUMN     "social_media_handles" JSONB;

-- DropTable
DROP TABLE "brand_profile";
