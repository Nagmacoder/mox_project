-- AlterTable
ALTER TABLE "audience_fields" ADD COLUMN     "is_mandatory" BOOLEAN NOT NULL DEFAULT false;
