-- AlterTable
ALTER TABLE "DataProof" ADD COLUMN     "users_count" INTEGER;
