/*
  Warnings:

  - You are about to drop the column `api_endpoints` on the `ClientDBInfo` table. All the data in the column will be lost.
  - Added the required column `client_db_password` to the `ClientDBInfo` table without a default value. This is not possible if the table is not empty.
  - Added the required column `client_db_username` to the `ClientDBInfo` table without a default value. This is not possible if the table is not empty.
  - Added the required column `client_dbname` to the `ClientDBInfo` table without a default value. This is not possible if the table is not empty.

*/
-- CreateEnum
CREATE TYPE "CampaignStatus" AS ENUM ('CREATED', 'REQUESTED', 'OFFER_ACCEPTED');

-- AlterTable
ALTER TABLE "ClientDBInfo" DROP COLUMN "api_endpoints",
ADD COLUMN     "client_db_password" VARCHAR(255) NOT NULL,
ADD COLUMN     "client_db_username" VARCHAR(255) NOT NULL,
ADD COLUMN     "client_dbname" VARCHAR(255) NOT NULL;

-- AlterTable
ALTER TABLE "campaign" ADD COLUMN     "status" "CampaignStatus" NOT NULL DEFAULT 'CREATED';
