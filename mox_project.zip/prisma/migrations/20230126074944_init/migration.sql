/*
  Warnings:

  - You are about to drop the column `receiver_brand` on the `DataProof` table. All the data in the column will be lost.
  - You are about to drop the column `receiver_business_entity` on the `DataProof` table. All the data in the column will be lost.
  - You are about to drop the column `sender_brand` on the `DataProof` table. All the data in the column will be lost.
  - You are about to drop the column `sender_business_entity` on the `DataProof` table. All the data in the column will be lost.
  - You are about to drop the column `sender_campaign` on the `DataProof` table. All the data in the column will be lost.
  - Added the required column `receiver_brand_id` to the `DataProof` table without a default value. This is not possible if the table is not empty.
  - Added the required column `receiver_business_entity_id` to the `DataProof` table without a default value. This is not possible if the table is not empty.
  - Added the required column `sender_brand_id` to the `DataProof` table without a default value. This is not possible if the table is not empty.
  - Added the required column `sender_business_entity_id` to the `DataProof` table without a default value. This is not possible if the table is not empty.
  - Added the required column `sender_campaign_id` to the `DataProof` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "DataProof" DROP COLUMN "receiver_brand",
DROP COLUMN "receiver_business_entity",
DROP COLUMN "sender_brand",
DROP COLUMN "sender_business_entity",
DROP COLUMN "sender_campaign",
ADD COLUMN     "receiver_brand_id" INTEGER NOT NULL,
ADD COLUMN     "receiver_business_entity_id" INTEGER NOT NULL,
ADD COLUMN     "sender_brand_id" INTEGER NOT NULL,
ADD COLUMN     "sender_business_entity_id" INTEGER NOT NULL,
ADD COLUMN     "sender_campaign_id" INTEGER NOT NULL;

-- AddForeignKey
ALTER TABLE "DataProof" ADD CONSTRAINT "DataProof_sender_business_entity_id_fkey" FOREIGN KEY ("sender_business_entity_id") REFERENCES "BusinessEntity"("business_entity_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DataProof" ADD CONSTRAINT "DataProof_sender_brand_id_fkey" FOREIGN KEY ("sender_brand_id") REFERENCES "brand"("brand_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DataProof" ADD CONSTRAINT "DataProof_sender_campaign_id_fkey" FOREIGN KEY ("sender_campaign_id") REFERENCES "campaign"("campaign_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DataProof" ADD CONSTRAINT "DataProof_receiver_business_entity_id_fkey" FOREIGN KEY ("receiver_business_entity_id") REFERENCES "BusinessEntity"("business_entity_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DataProof" ADD CONSTRAINT "DataProof_receiver_brand_id_fkey" FOREIGN KEY ("receiver_brand_id") REFERENCES "brand"("brand_id") ON DELETE RESTRICT ON UPDATE CASCADE;
