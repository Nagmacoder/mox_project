-- CreateTable
CREATE TABLE "Languages" (
    "language_id" SERIAL NOT NULL,
    "language_name" VARCHAR(255) NOT NULL,
    "language_code" VARCHAR(255) NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Languages_pkey" PRIMARY KEY ("language_id")
);
