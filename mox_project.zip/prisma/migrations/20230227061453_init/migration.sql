-- AlterTable
ALTER TABLE "UserAccount" ADD COLUMN     "code" TEXT;
