-- AlterTable
ALTER TABLE "campaign" ADD COLUMN     "preview_image" TEXT;

-- CreateTable
CREATE TABLE "CampaignCreatives" (
    "creative_id" SERIAL NOT NULL,
    "campaign_id" INTEGER NOT NULL,
    "banner_type" TEXT,
    "banner_size" TEXT,
    "banner_format" TEXT,
    "url" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CampaignCreatives_pkey" PRIMARY KEY ("creative_id")
);

-- AddForeignKey
ALTER TABLE "CampaignCreatives" ADD CONSTRAINT "CampaignCreatives_campaign_id_fkey" FOREIGN KEY ("campaign_id") REFERENCES "campaign"("campaign_id") ON DELETE RESTRICT ON UPDATE CASCADE;
