/*
  Warnings:

  - You are about to drop the column `annual_income` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `approx_total` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `audience_name` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `audience_type` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `avg_spent_per_cart_max` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `avg_spent_per_cart_min` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `gender_type` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `occupation` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `psychographics` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `social_media_preferences` on the `audience` table. All the data in the column will be lost.
  - Added the required column `approx_mau` to the `audience` table without a default value. This is not possible if the table is not empty.
  - Added the required column `arpu` to the `audience` table without a default value. This is not possible if the table is not empty.
  - Added the required column `audience_group` to the `audience` table without a default value. This is not possible if the table is not empty.
  - Added the required column `gender` to the `audience` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "audience" DROP COLUMN "annual_income",
DROP COLUMN "approx_total",
DROP COLUMN "audience_name",
DROP COLUMN "audience_type",
DROP COLUMN "avg_spent_per_cart_max",
DROP COLUMN "avg_spent_per_cart_min",
DROP COLUMN "gender_type",
DROP COLUMN "occupation",
DROP COLUMN "psychographics",
DROP COLUMN "social_media_preferences",
ADD COLUMN     "approx_mau" VARCHAR(255) NOT NULL,
ADD COLUMN     "arpu" VARCHAR(255) NOT NULL,
ADD COLUMN     "audience_group" VARCHAR(255) NOT NULL,
ADD COLUMN     "gender" VARCHAR(255) NOT NULL;
