-- AlterTable
ALTER TABLE "ConnectionRequest" ADD COLUMN     "accepted_reason" TEXT,
ADD COLUMN     "rejected_reason" TEXT;
