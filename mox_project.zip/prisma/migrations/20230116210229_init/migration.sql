/*
  Warnings:

  - A unique constraint covering the columns `[brand_id]` on the table `ClientDBInfo` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `brand_id` to the `ClientDBInfo` table without a default value. This is not possible if the table is not empty.
  - Added the required column `client_dbname` to the `ClientDBInfo` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "ClientDBInfo" ADD COLUMN     "brand_id" INTEGER NOT NULL,
ADD COLUMN     "client_dbname" VARCHAR(255) NOT NULL;

-- CreateTable
CREATE TABLE "DataProof" (
    "proof_id" SERIAL NOT NULL,
    "sender_business_entity" INTEGER NOT NULL,
    "sender_brand" INTEGER NOT NULL,
    "sender_campaign" INTEGER NOT NULL,
    "receiver_business_entity" INTEGER NOT NULL,
    "receiver_brand" INTEGER NOT NULL,
    "proof" JSONB NOT NULL,
    "solidity" TEXT NOT NULL,

    CONSTRAINT "DataProof_pkey" PRIMARY KEY ("proof_id")
);

-- CreateIndex
CREATE UNIQUE INDEX "ClientDBInfo_brand_id_key" ON "ClientDBInfo"("brand_id");

-- AddForeignKey
ALTER TABLE "ClientDBInfo" ADD CONSTRAINT "ClientDBInfo_brand_id_fkey" FOREIGN KEY ("brand_id") REFERENCES "brand"("brand_id") ON DELETE RESTRICT ON UPDATE CASCADE;
