/*
  Warnings:

  - You are about to drop the column `client_db_password` on the `ClientDBInfo` table. All the data in the column will be lost.
  - You are about to drop the column `client_db_username` on the `ClientDBInfo` table. All the data in the column will be lost.
  - You are about to drop the column `client_dbname` on the `ClientDBInfo` table. All the data in the column will be lost.
  - Added the required column `api_endpoints` to the `ClientDBInfo` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "ClientDBInfo" DROP COLUMN "client_db_password",
DROP COLUMN "client_db_username",
DROP COLUMN "client_dbname",
ADD COLUMN     "api_endpoints" JSONB NOT NULL;
