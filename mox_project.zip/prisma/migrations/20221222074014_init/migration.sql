/*
  Warnings:

  - Added the required column `p_id` to the `UserAccount` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "UserAccount" ADD COLUMN     "p_id" VARCHAR(255) NOT NULL;
