-- CreateTable
CREATE TABLE "UserPids" (
    "id" SERIAL NOT NULL,
    "sender_business_entity_id" INTEGER NOT NULL,
    "sender_brand_id" INTEGER NOT NULL,
    "sender_campaign_id" INTEGER NOT NULL,
    "receiver_business_entity_id" INTEGER NOT NULL,
    "receiver_brand_id" INTEGER NOT NULL,
    "p_id" VARCHAR(255) NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "UserPids_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "UserPids" ADD CONSTRAINT "UserPids_sender_business_entity_id_fkey" FOREIGN KEY ("sender_business_entity_id") REFERENCES "BusinessEntity"("business_entity_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserPids" ADD CONSTRAINT "UserPids_sender_brand_id_fkey" FOREIGN KEY ("sender_brand_id") REFERENCES "brand"("brand_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserPids" ADD CONSTRAINT "UserPids_sender_campaign_id_fkey" FOREIGN KEY ("sender_campaign_id") REFERENCES "campaign"("campaign_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserPids" ADD CONSTRAINT "UserPids_receiver_business_entity_id_fkey" FOREIGN KEY ("receiver_business_entity_id") REFERENCES "BusinessEntity"("business_entity_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserPids" ADD CONSTRAINT "UserPids_receiver_brand_id_fkey" FOREIGN KEY ("receiver_brand_id") REFERENCES "brand"("brand_id") ON DELETE RESTRICT ON UPDATE CASCADE;
