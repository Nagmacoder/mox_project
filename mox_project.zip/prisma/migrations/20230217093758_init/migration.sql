-- CreateTable
CREATE TABLE "FieldMapping" (
    "id" SERIAL NOT NULL,
    "field_name" VARCHAR(255) NOT NULL,
    "amazon" JSONB,
    "swiggy" JSONB,
    "zomato" JSONB,

    CONSTRAINT "FieldMapping_pkey" PRIMARY KEY ("id")
);
