-- AlterEnum
ALTER TYPE "CampaignStatus" ADD VALUE 'ACTIVE';

-- AlterTable
ALTER TABLE "UserAccount" ADD COLUMN     "resetToken" TEXT;
