-- CreateEnum
CREATE TYPE "BusinessEntityTypeName" AS ENUM ('DATA_CONSUMER', 'DATA_PROVIDER', 'BOTH');

-- CreateTable
CREATE TABLE "BusinessEntityType" (
    "business_entity_type_id" SERIAL NOT NULL,
    "business_entity_type_name" "BusinessEntityTypeName" NOT NULL DEFAULT 'BOTH',
    "description" VARCHAR(255) NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BusinessEntityType_pkey" PRIMARY KEY ("business_entity_type_id")
);

-- CreateTable
CREATE TABLE "BusinessEntity" (
    "business_entity_id" SERIAL NOT NULL,
    "business_entity_type_id" INTEGER NOT NULL,
    "given_name" VARCHAR(255) NOT NULL,
    "family_name" VARCHAR(255) NOT NULL,
    "email" VARCHAR(255) NOT NULL,
    "display_name" VARCHAR(255) NOT NULL,
    "category" TEXT,
    "industry_type" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BusinessEntity_pkey" PRIMARY KEY ("business_entity_id")
);

-- CreateTable
CREATE TABLE "UserAccount" (
    "user_id" SERIAL NOT NULL,
    "email" VARCHAR(255) NOT NULL,
    "password_hash" VARCHAR(255) NOT NULL,
    "password_salt" VARCHAR(255) NOT NULL,
    "business_entity_id" INTEGER NOT NULL,
    "login_as" INTEGER NOT NULL,
    "is_active" BOOLEAN NOT NULL,
    "is_email_verified" BOOLEAN NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "UserAccount_pkey" PRIMARY KEY ("user_id")
);

-- CreateTable
CREATE TABLE "Role" (
    "user_role_id" SERIAL NOT NULL,
    "user_role_name" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "role_type" INTEGER NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Role_pkey" PRIMARY KEY ("user_role_id")
);

-- CreateTable
CREATE TABLE "UserAccountRole" (
    "user_account_role_id" SERIAL NOT NULL,
    "user_id" INTEGER NOT NULL,
    "user_role_id" INTEGER NOT NULL,

    CONSTRAINT "UserAccountRole_pkey" PRIMARY KEY ("user_account_role_id")
);

-- CreateTable
CREATE TABLE "RoleModule" (
    "role_module_id" SERIAL NOT NULL,
    "user_role_id" INTEGER NOT NULL,
    "module_id" INTEGER NOT NULL,

    CONSTRAINT "RoleModule_pkey" PRIMARY KEY ("role_module_id")
);

-- CreateTable
CREATE TABLE "Module" (
    "module_id" SERIAL NOT NULL,
    "module_name" VARCHAR(255) NOT NULL,

    CONSTRAINT "Module_pkey" PRIMARY KEY ("module_id")
);

-- CreateTable
CREATE TABLE "permission" (
    "permission_id" SERIAL NOT NULL,
    "permission_name" VARCHAR(255) NOT NULL,

    CONSTRAINT "permission_pkey" PRIMARY KEY ("permission_id")
);

-- CreateIndex
CREATE UNIQUE INDEX "BusinessEntity_business_entity_type_id_key" ON "BusinessEntity"("business_entity_type_id");

-- CreateIndex
CREATE UNIQUE INDEX "UserAccount_business_entity_id_key" ON "UserAccount"("business_entity_id");

-- CreateIndex
CREATE UNIQUE INDEX "UserAccountRole_user_id_key" ON "UserAccountRole"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "RoleModule_user_role_id_key" ON "RoleModule"("user_role_id");

-- AddForeignKey
ALTER TABLE "BusinessEntity" ADD CONSTRAINT "BusinessEntity_business_entity_type_id_fkey" FOREIGN KEY ("business_entity_type_id") REFERENCES "BusinessEntityType"("business_entity_type_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserAccount" ADD CONSTRAINT "UserAccount_business_entity_id_fkey" FOREIGN KEY ("business_entity_id") REFERENCES "BusinessEntity"("business_entity_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserAccountRole" ADD CONSTRAINT "UserAccountRole_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "UserAccount"("user_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserAccountRole" ADD CONSTRAINT "UserAccountRole_user_role_id_fkey" FOREIGN KEY ("user_role_id") REFERENCES "Role"("user_role_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RoleModule" ADD CONSTRAINT "RoleModule_user_role_id_fkey" FOREIGN KEY ("user_role_id") REFERENCES "Role"("user_role_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RoleModule" ADD CONSTRAINT "RoleModule_module_id_fkey" FOREIGN KEY ("module_id") REFERENCES "Module"("module_id") ON DELETE RESTRICT ON UPDATE CASCADE;
