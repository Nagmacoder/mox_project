/*
  Warnings:

  - You are about to drop the column `age_range_max` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `age_range_min` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `approx_mau` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `arpu` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `audience_category` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `audience_group` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `audience_location` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `gender` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `languages` on the `audience` table. All the data in the column will be lost.
  - You are about to drop the column `about` on the `campaign` table. All the data in the column will be lost.
  - You are about to drop the column `budget_max` on the `campaign` table. All the data in the column will be lost.
  - You are about to drop the column `budget_min` on the `campaign` table. All the data in the column will be lost.
  - You are about to drop the column `campaign_name` on the `campaign` table. All the data in the column will be lost.
  - You are about to drop the column `category` on the `campaign` table. All the data in the column will be lost.
  - You are about to drop the column `conversion_type` on the `campaign` table. All the data in the column will be lost.
  - You are about to drop the column `creatives` on the `campaign` table. All the data in the column will be lost.
  - You are about to drop the column `destination_url` on the `campaign` table. All the data in the column will be lost.
  - You are about to drop the column `end_duration` on the `campaign` table. All the data in the column will be lost.
  - You are about to drop the column `mau` on the `campaign` table. All the data in the column will be lost.
  - You are about to drop the column `payout_percent` on the `campaign` table. All the data in the column will be lost.
  - You are about to drop the column `payout_terms` on the `campaign` table. All the data in the column will be lost.
  - You are about to drop the column `start_duration` on the `campaign` table. All the data in the column will be lost.
  - You are about to drop the column `trial_period` on the `campaign` table. All the data in the column will be lost.
  - You are about to drop the column `volume` on the `campaign` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "audience" DROP COLUMN "age_range_max",
DROP COLUMN "age_range_min",
DROP COLUMN "approx_mau",
DROP COLUMN "arpu",
DROP COLUMN "audience_category",
DROP COLUMN "audience_group",
DROP COLUMN "audience_location",
DROP COLUMN "gender",
DROP COLUMN "languages";

-- AlterTable
ALTER TABLE "campaign" DROP COLUMN "about",
DROP COLUMN "budget_max",
DROP COLUMN "budget_min",
DROP COLUMN "campaign_name",
DROP COLUMN "category",
DROP COLUMN "conversion_type",
DROP COLUMN "creatives",
DROP COLUMN "destination_url",
DROP COLUMN "end_duration",
DROP COLUMN "mau",
DROP COLUMN "payout_percent",
DROP COLUMN "payout_terms",
DROP COLUMN "start_duration",
DROP COLUMN "trial_period",
DROP COLUMN "volume";

-- CreateTable
CREATE TABLE "audience_fields" (
    "field_id" SERIAL NOT NULL,
    "audience_id" INTEGER NOT NULL,
    "field_name" VARCHAR(255) NOT NULL,
    "field_value" VARCHAR(255) NOT NULL,
    "is_mandatory" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "audience_fields_pkey" PRIMARY KEY ("field_id")
);

-- CreateTable
CREATE TABLE "campaign_fields" (
    "field_id" SERIAL NOT NULL,
    "campaign_id" INTEGER NOT NULL,
    "field_name" VARCHAR(255) NOT NULL,
    "field_value" VARCHAR(255) NOT NULL,
    "is_mandatory" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "campaign_fields_pkey" PRIMARY KEY ("field_id")
);

-- AddForeignKey
ALTER TABLE "audience_fields" ADD CONSTRAINT "audience_fields_audience_id_fkey" FOREIGN KEY ("audience_id") REFERENCES "audience"("audience_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "campaign_fields" ADD CONSTRAINT "campaign_fields_campaign_id_fkey" FOREIGN KEY ("campaign_id") REFERENCES "campaign"("campaign_id") ON DELETE RESTRICT ON UPDATE CASCADE;
