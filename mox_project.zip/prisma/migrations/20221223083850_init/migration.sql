/*
  Warnings:

  - You are about to drop the column `user_id` on the `brand` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[business_entity_id]` on the table `brand` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `business_entity_id` to the `brand` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "brand" DROP CONSTRAINT "brand_user_id_fkey";

-- DropIndex
DROP INDEX "brand_user_id_key";

-- AlterTable
ALTER TABLE "brand" DROP COLUMN "user_id",
ADD COLUMN     "business_entity_id" INTEGER NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "brand_business_entity_id_key" ON "brand"("business_entity_id");

-- AddForeignKey
ALTER TABLE "brand" ADD CONSTRAINT "brand_business_entity_id_fkey" FOREIGN KEY ("business_entity_id") REFERENCES "BusinessEntity"("business_entity_id") ON DELETE RESTRICT ON UPDATE CASCADE;
