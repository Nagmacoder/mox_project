-- AlterTable
ALTER TABLE "FieldMapping" ADD COLUMN     "myntra" JSONB;
