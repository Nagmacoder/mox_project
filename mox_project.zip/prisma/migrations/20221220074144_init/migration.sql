-- DropIndex
DROP INDEX "BusinessEntity_business_entity_type_id_key";

-- AlterTable
ALTER TABLE "UserAccount" ALTER COLUMN "is_active" DROP NOT NULL;
