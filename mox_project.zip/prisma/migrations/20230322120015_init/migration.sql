/*
  Warnings:

  - You are about to drop the column `accepted_reason` on the `ConnectionRequest` table. All the data in the column will be lost.
  - You are about to drop the column `rejected_reason` on the `ConnectionRequest` table. All the data in the column will be lost.

*/
-- AlterEnum
ALTER TYPE "RequestStatus" ADD VALUE 'PENDING';

-- AlterTable
ALTER TABLE "ConnectionRequest" DROP COLUMN "accepted_reason",
DROP COLUMN "rejected_reason",
ADD COLUMN     "dc_note" TEXT,
ADD COLUMN     "dp_note" TEXT;
