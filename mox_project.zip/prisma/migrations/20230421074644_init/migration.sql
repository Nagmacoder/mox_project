-- AlterTable
ALTER TABLE "FieldMapping" ADD COLUMN     "velocity" JSONB;

-- AlterTable
ALTER TABLE "UserAccount" ADD COLUMN     "account_status" INTEGER NOT NULL DEFAULT 1;
