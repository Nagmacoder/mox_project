/*
  Warnings:

  - You are about to drop the column `receiver_id` on the `ConnectionRequest` table. All the data in the column will be lost.
  - You are about to drop the column `sender_id` on the `ConnectionRequest` table. All the data in the column will be lost.
  - Added the required column `receiver_brandId` to the `ConnectionRequest` table without a default value. This is not possible if the table is not empty.
  - Added the required column `receiver_userId` to the `ConnectionRequest` table without a default value. This is not possible if the table is not empty.
  - Added the required column `sender_brandId` to the `ConnectionRequest` table without a default value. This is not possible if the table is not empty.
  - Added the required column `sender_userId` to the `ConnectionRequest` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "ConnectionRequest" DROP CONSTRAINT "ConnectionRequest_receiver_id_fkey";

-- DropForeignKey
ALTER TABLE "ConnectionRequest" DROP CONSTRAINT "ConnectionRequest_sender_id_fkey";

-- AlterTable
ALTER TABLE "ConnectionRequest" DROP COLUMN "receiver_id",
DROP COLUMN "sender_id",
ADD COLUMN     "receiver_brandId" INTEGER NOT NULL,
ADD COLUMN     "receiver_userId" INTEGER NOT NULL,
ADD COLUMN     "sender_brandId" INTEGER NOT NULL,
ADD COLUMN     "sender_userId" INTEGER NOT NULL;

-- CreateTable
CREATE TABLE "ClientDBInfo" (
    "id" SERIAL NOT NULL,
    "business_entity_id" INTEGER NOT NULL,
    "client_db_username" VARCHAR(255) NOT NULL,
    "client_db_password" VARCHAR(255) NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ClientDBInfo_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "ClientDBInfo_business_entity_id_key" ON "ClientDBInfo"("business_entity_id");

-- AddForeignKey
ALTER TABLE "ConnectionRequest" ADD CONSTRAINT "ConnectionRequest_sender_userId_fkey" FOREIGN KEY ("sender_userId") REFERENCES "UserAccount"("user_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ConnectionRequest" ADD CONSTRAINT "ConnectionRequest_receiver_userId_fkey" FOREIGN KEY ("receiver_userId") REFERENCES "UserAccount"("user_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ConnectionRequest" ADD CONSTRAINT "ConnectionRequest_sender_brandId_fkey" FOREIGN KEY ("sender_brandId") REFERENCES "brand"("brand_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ConnectionRequest" ADD CONSTRAINT "ConnectionRequest_receiver_brandId_fkey" FOREIGN KEY ("receiver_brandId") REFERENCES "brand"("brand_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ClientDBInfo" ADD CONSTRAINT "ClientDBInfo_business_entity_id_fkey" FOREIGN KEY ("business_entity_id") REFERENCES "BusinessEntity"("business_entity_id") ON DELETE RESTRICT ON UPDATE CASCADE;
