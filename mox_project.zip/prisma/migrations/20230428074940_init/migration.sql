-- DropIndex
DROP INDEX "UserAccount_business_entity_id_key";

-- AlterTable
ALTER TABLE "UserAccount" ALTER COLUMN "account_status" SET DEFAULT 0;
