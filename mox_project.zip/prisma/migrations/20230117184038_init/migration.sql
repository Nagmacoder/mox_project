/*
  Warnings:

  - Added the required column `pids` to the `DataProof` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "DataProof" ADD COLUMN     "pids" JSONB NOT NULL;
