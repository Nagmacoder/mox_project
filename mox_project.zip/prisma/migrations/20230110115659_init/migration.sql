-- AlterTable
ALTER TABLE "ConnectionRequest" ADD COLUMN     "sender_campaignId" INTEGER NOT NULL DEFAULT 0;

-- AddForeignKey
ALTER TABLE "ConnectionRequest" ADD CONSTRAINT "ConnectionRequest_sender_campaignId_fkey" FOREIGN KEY ("sender_campaignId") REFERENCES "campaign"("campaign_id") ON DELETE RESTRICT ON UPDATE CASCADE;
