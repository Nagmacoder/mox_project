import App from "./providers/App";

App.loadServer();
