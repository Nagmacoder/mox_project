--
-- PostgreSQL database dump
--

-- Dumped from database version 14.7 (Ubuntu 14.7-1.pgdg20.04+1)
-- Dumped by pg_dump version 15.2 (Ubuntu 15.2-1.pgdg20.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: mox; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA mox;


ALTER SCHEMA mox OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: BusinessEntityTypeName; Type: TYPE; Schema: mox; Owner: postgres
--

CREATE TYPE mox."BusinessEntityTypeName" AS ENUM (
    'PROMOTION_PARTNER',
    'MONETIZATION_PARTNER',
    'BOTH'
);


ALTER TYPE mox."BusinessEntityTypeName" OWNER TO postgres;

--
-- Name: CampaignStatus; Type: TYPE; Schema: mox; Owner: postgres
--

CREATE TYPE mox."CampaignStatus" AS ENUM (
    'CREATED',
    'REQUESTED',
    'OFFER_ACCEPTED',
    'ACTIVE'
);


ALTER TYPE mox."CampaignStatus" OWNER TO postgres;

--
-- Name: RequestStatus; Type: TYPE; Schema: mox; Owner: postgres
--

CREATE TYPE mox."RequestStatus" AS ENUM (
    'REQUESTED',
    'ACCEPTED',
    'REJECTED',
    'CANCELLED',
    'PENDING'
);


ALTER TYPE mox."RequestStatus" OWNER TO postgres;

--
-- Name: RoleName; Type: TYPE; Schema: mox; Owner: postgres
--

CREATE TYPE mox."RoleName" AS ENUM (
    'SUPER_ADMIN',
    'ADMIN',
    'NORMAL_USER'
);


ALTER TYPE mox."RoleName" OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: BusinessCategories; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox."BusinessCategories" (
    business_category_id integer NOT NULL,
    business_category_name character varying(255) NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE mox."BusinessCategories" OWNER TO postgres;

--
-- Name: BusinessCategories_business_category_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox."BusinessCategories_business_category_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox."BusinessCategories_business_category_id_seq" OWNER TO postgres;

--
-- Name: BusinessCategories_business_category_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox."BusinessCategories_business_category_id_seq" OWNED BY mox."BusinessCategories".business_category_id;


--
-- Name: BusinessEntity; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox."BusinessEntity" (
    business_entity_id integer NOT NULL,
    business_entity_type_id integer NOT NULL,
    given_name character varying(255) NOT NULL,
    family_name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    category text,
    industry_type text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE mox."BusinessEntity" OWNER TO postgres;

--
-- Name: BusinessEntityType; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox."BusinessEntityType" (
    business_entity_type_id integer NOT NULL,
    business_entity_type_name mox."BusinessEntityTypeName" DEFAULT 'BOTH'::mox."BusinessEntityTypeName" NOT NULL,
    description character varying(255) NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE mox."BusinessEntityType" OWNER TO postgres;

--
-- Name: BusinessEntityType_business_entity_type_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox."BusinessEntityType_business_entity_type_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox."BusinessEntityType_business_entity_type_id_seq" OWNER TO postgres;

--
-- Name: BusinessEntityType_business_entity_type_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox."BusinessEntityType_business_entity_type_id_seq" OWNED BY mox."BusinessEntityType".business_entity_type_id;


--
-- Name: BusinessEntity_business_entity_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox."BusinessEntity_business_entity_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox."BusinessEntity_business_entity_id_seq" OWNER TO postgres;

--
-- Name: BusinessEntity_business_entity_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox."BusinessEntity_business_entity_id_seq" OWNED BY mox."BusinessEntity".business_entity_id;


--
-- Name: CampaignCreatives; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox."CampaignCreatives" (
    creative_id integer NOT NULL,
    campaign_id integer NOT NULL,
    banner_type text,
    banner_size text,
    banner_format text,
    url text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE mox."CampaignCreatives" OWNER TO postgres;

--
-- Name: CampaignCreatives_creative_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox."CampaignCreatives_creative_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox."CampaignCreatives_creative_id_seq" OWNER TO postgres;

--
-- Name: CampaignCreatives_creative_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox."CampaignCreatives_creative_id_seq" OWNED BY mox."CampaignCreatives".creative_id;


--
-- Name: ClientDBInfo; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox."ClientDBInfo" (
    id integer NOT NULL,
    business_entity_id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    brand_id integer NOT NULL,
    client_db_password character varying(255) NOT NULL,
    client_db_username character varying(255) NOT NULL,
    client_dbname character varying(255) NOT NULL
);


ALTER TABLE mox."ClientDBInfo" OWNER TO postgres;

--
-- Name: ClientDBInfo_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox."ClientDBInfo_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox."ClientDBInfo_id_seq" OWNER TO postgres;

--
-- Name: ClientDBInfo_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox."ClientDBInfo_id_seq" OWNED BY mox."ClientDBInfo".id;


--
-- Name: ConnectionRequest; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox."ConnectionRequest" (
    request_id integer NOT NULL,
    "isAccepted" boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "receiver_brandId" integer NOT NULL,
    "receiver_userId" integer NOT NULL,
    "sender_brandId" integer NOT NULL,
    "sender_userId" integer NOT NULL,
    "sender_campaignId" integer DEFAULT 0 NOT NULL,
    "requestStatus" mox."RequestStatus" DEFAULT 'REQUESTED'::mox."RequestStatus" NOT NULL,
    dc_note text,
    dp_note text
);


ALTER TABLE mox."ConnectionRequest" OWNER TO postgres;

--
-- Name: ConnectionRequest_request_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox."ConnectionRequest_request_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox."ConnectionRequest_request_id_seq" OWNER TO postgres;

--
-- Name: ConnectionRequest_request_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox."ConnectionRequest_request_id_seq" OWNED BY mox."ConnectionRequest".request_id;


--
-- Name: CountriesData; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox."CountriesData" (
    country_id integer NOT NULL,
    country_name character varying(255) NOT NULL,
    country_code text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE mox."CountriesData" OWNER TO postgres;

--
-- Name: CountriesData_country_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox."CountriesData_country_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox."CountriesData_country_id_seq" OWNER TO postgres;

--
-- Name: CountriesData_country_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox."CountriesData_country_id_seq" OWNED BY mox."CountriesData".country_id;


--
-- Name: DataProof; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox."DataProof" (
    proof_id integer NOT NULL,
    proof jsonb,
    solidity text,
    pids jsonb NOT NULL,
    "contractAddress" text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "isVerified" boolean DEFAULT false NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    receiver_brand_id integer NOT NULL,
    receiver_business_entity_id integer NOT NULL,
    sender_brand_id integer NOT NULL,
    sender_business_entity_id integer NOT NULL,
    sender_campaign_id integer NOT NULL,
    users_count integer
);


ALTER TABLE mox."DataProof" OWNER TO postgres;

--
-- Name: DataProof_proof_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox."DataProof_proof_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox."DataProof_proof_id_seq" OWNER TO postgres;

--
-- Name: DataProof_proof_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox."DataProof_proof_id_seq" OWNED BY mox."DataProof".proof_id;


--
-- Name: FieldMapping; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox."FieldMapping" (
    id integer NOT NULL,
    field_name character varying(255) NOT NULL,
    amazon jsonb,
    swiggy jsonb,
    zomato jsonb,
    myntra jsonb,
    velocity jsonb
);


ALTER TABLE mox."FieldMapping" OWNER TO postgres;

--
-- Name: FieldMapping_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox."FieldMapping_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox."FieldMapping_id_seq" OWNER TO postgres;

--
-- Name: FieldMapping_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox."FieldMapping_id_seq" OWNED BY mox."FieldMapping".id;


--
-- Name: Languages; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox."Languages" (
    language_id integer NOT NULL,
    language_name character varying(255) NOT NULL,
    language_code character varying(255) NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE mox."Languages" OWNER TO postgres;

--
-- Name: Languages_language_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox."Languages_language_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox."Languages_language_id_seq" OWNER TO postgres;

--
-- Name: Languages_language_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox."Languages_language_id_seq" OWNED BY mox."Languages".language_id;


--
-- Name: Module; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox."Module" (
    module_id integer NOT NULL,
    module_name character varying(255) NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE mox."Module" OWNER TO postgres;

--
-- Name: Module_module_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox."Module_module_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox."Module_module_id_seq" OWNER TO postgres;

--
-- Name: Module_module_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox."Module_module_id_seq" OWNED BY mox."Module".module_id;


--
-- Name: Role; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox."Role" (
    user_role_id integer NOT NULL,
    user_role_name character varying(255) NOT NULL,
    description text,
    role_type integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE mox."Role" OWNER TO postgres;

--
-- Name: RoleModule; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox."RoleModule" (
    role_module_id integer NOT NULL,
    user_role_id integer NOT NULL,
    module_id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE mox."RoleModule" OWNER TO postgres;

--
-- Name: RoleModule_role_module_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox."RoleModule_role_module_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox."RoleModule_role_module_id_seq" OWNER TO postgres;

--
-- Name: RoleModule_role_module_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox."RoleModule_role_module_id_seq" OWNED BY mox."RoleModule".role_module_id;


--
-- Name: Role_user_role_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox."Role_user_role_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox."Role_user_role_id_seq" OWNER TO postgres;

--
-- Name: Role_user_role_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox."Role_user_role_id_seq" OWNED BY mox."Role".user_role_id;


--
-- Name: UserAccount; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox."UserAccount" (
    user_id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    password_salt character varying(255) NOT NULL,
    business_entity_id integer NOT NULL,
    login_as integer NOT NULL,
    is_active boolean,
    is_email_verified boolean NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    p_id character varying(255) NOT NULL,
    code text,
    "resetToken" text,
    role_name mox."RoleName" DEFAULT 'NORMAL_USER'::mox."RoleName" NOT NULL,
    account_status integer DEFAULT 0 NOT NULL
);


ALTER TABLE mox."UserAccount" OWNER TO postgres;

--
-- Name: UserAccountRole; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox."UserAccountRole" (
    user_account_role_id integer NOT NULL,
    user_id integer NOT NULL,
    user_role_id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE mox."UserAccountRole" OWNER TO postgres;

--
-- Name: UserAccountRole_user_account_role_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox."UserAccountRole_user_account_role_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox."UserAccountRole_user_account_role_id_seq" OWNER TO postgres;

--
-- Name: UserAccountRole_user_account_role_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox."UserAccountRole_user_account_role_id_seq" OWNED BY mox."UserAccountRole".user_account_role_id;


--
-- Name: UserAccount_user_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox."UserAccount_user_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox."UserAccount_user_id_seq" OWNER TO postgres;

--
-- Name: UserAccount_user_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox."UserAccount_user_id_seq" OWNED BY mox."UserAccount".user_id;


--
-- Name: UserPids; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox."UserPids" (
    id integer NOT NULL,
    sender_business_entity_id integer NOT NULL,
    sender_brand_id integer NOT NULL,
    sender_campaign_id integer NOT NULL,
    receiver_business_entity_id integer NOT NULL,
    receiver_brand_id integer NOT NULL,
    p_id character varying(255) NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE mox."UserPids" OWNER TO postgres;

--
-- Name: UserPids_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox."UserPids_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox."UserPids_id_seq" OWNER TO postgres;

--
-- Name: UserPids_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox."UserPids_id_seq" OWNED BY mox."UserPids".id;


--
-- Name: _prisma_migrations; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE mox._prisma_migrations OWNER TO postgres;

--
-- Name: audience; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox.audience (
    audience_id integer NOT NULL,
    brand_id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE mox.audience OWNER TO postgres;

--
-- Name: audience_audience_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox.audience_audience_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox.audience_audience_id_seq OWNER TO postgres;

--
-- Name: audience_audience_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox.audience_audience_id_seq OWNED BY mox.audience.audience_id;


--
-- Name: audience_fields; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox.audience_fields (
    field_id integer NOT NULL,
    audience_id integer NOT NULL,
    field_name character varying(255) NOT NULL,
    field_value jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    is_mandatory boolean DEFAULT false NOT NULL
);


ALTER TABLE mox.audience_fields OWNER TO postgres;

--
-- Name: audience_fields_field_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox.audience_fields_field_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox.audience_fields_field_id_seq OWNER TO postgres;

--
-- Name: audience_fields_field_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox.audience_fields_field_id_seq OWNED BY mox.audience_fields.field_id;


--
-- Name: brand; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox.brand (
    brand_id integer NOT NULL,
    brand_name character varying(255) NOT NULL,
    website character varying(255) NOT NULL,
    business_entity_id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    about text,
    audience_location jsonb,
    languages jsonb,
    logo text,
    mau text,
    online_store text,
    site_category text,
    social_media_handles jsonb
);


ALTER TABLE mox.brand OWNER TO postgres;

--
-- Name: brand_brand_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox.brand_brand_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox.brand_brand_id_seq OWNER TO postgres;

--
-- Name: brand_brand_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox.brand_brand_id_seq OWNED BY mox.brand.brand_id;


--
-- Name: campaign; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox.campaign (
    campaign_id integer NOT NULL,
    brand_id integer NOT NULL,
    audience_id integer NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status mox."CampaignStatus" DEFAULT 'CREATED'::mox."CampaignStatus" NOT NULL,
    preview_image text
);


ALTER TABLE mox.campaign OWNER TO postgres;

--
-- Name: campaign_campaign_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox.campaign_campaign_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox.campaign_campaign_id_seq OWNER TO postgres;

--
-- Name: campaign_campaign_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox.campaign_campaign_id_seq OWNED BY mox.campaign.campaign_id;


--
-- Name: campaign_fields; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox.campaign_fields (
    field_id integer NOT NULL,
    campaign_id integer NOT NULL,
    field_name character varying(255) NOT NULL,
    field_value jsonb NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE mox.campaign_fields OWNER TO postgres;

--
-- Name: campaign_fields_field_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox.campaign_fields_field_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox.campaign_fields_field_id_seq OWNER TO postgres;

--
-- Name: campaign_fields_field_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox.campaign_fields_field_id_seq OWNED BY mox.campaign_fields.field_id;


--
-- Name: location; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox.location (
    location_id integer NOT NULL,
    location_name character varying(255) NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE mox.location OWNER TO postgres;

--
-- Name: location_location_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox.location_location_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox.location_location_id_seq OWNER TO postgres;

--
-- Name: location_location_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox.location_location_id_seq OWNED BY mox.location.location_id;


--
-- Name: permission; Type: TABLE; Schema: mox; Owner: postgres
--

CREATE TABLE mox.permission (
    permission_id integer NOT NULL,
    permission_name character varying(255) NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE mox.permission OWNER TO postgres;

--
-- Name: permission_permission_id_seq; Type: SEQUENCE; Schema: mox; Owner: postgres
--

CREATE SEQUENCE mox.permission_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mox.permission_permission_id_seq OWNER TO postgres;

--
-- Name: permission_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: mox; Owner: postgres
--

ALTER SEQUENCE mox.permission_permission_id_seq OWNED BY mox.permission.permission_id;


--
-- Name: BusinessCategories business_category_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."BusinessCategories" ALTER COLUMN business_category_id SET DEFAULT nextval('mox."BusinessCategories_business_category_id_seq"'::regclass);


--
-- Name: BusinessEntity business_entity_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."BusinessEntity" ALTER COLUMN business_entity_id SET DEFAULT nextval('mox."BusinessEntity_business_entity_id_seq"'::regclass);


--
-- Name: BusinessEntityType business_entity_type_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."BusinessEntityType" ALTER COLUMN business_entity_type_id SET DEFAULT nextval('mox."BusinessEntityType_business_entity_type_id_seq"'::regclass);


--
-- Name: CampaignCreatives creative_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."CampaignCreatives" ALTER COLUMN creative_id SET DEFAULT nextval('mox."CampaignCreatives_creative_id_seq"'::regclass);


--
-- Name: ClientDBInfo id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."ClientDBInfo" ALTER COLUMN id SET DEFAULT nextval('mox."ClientDBInfo_id_seq"'::regclass);


--
-- Name: ConnectionRequest request_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."ConnectionRequest" ALTER COLUMN request_id SET DEFAULT nextval('mox."ConnectionRequest_request_id_seq"'::regclass);


--
-- Name: CountriesData country_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."CountriesData" ALTER COLUMN country_id SET DEFAULT nextval('mox."CountriesData_country_id_seq"'::regclass);


--
-- Name: DataProof proof_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."DataProof" ALTER COLUMN proof_id SET DEFAULT nextval('mox."DataProof_proof_id_seq"'::regclass);


--
-- Name: FieldMapping id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."FieldMapping" ALTER COLUMN id SET DEFAULT nextval('mox."FieldMapping_id_seq"'::regclass);


--
-- Name: Languages language_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."Languages" ALTER COLUMN language_id SET DEFAULT nextval('mox."Languages_language_id_seq"'::regclass);


--
-- Name: Module module_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."Module" ALTER COLUMN module_id SET DEFAULT nextval('mox."Module_module_id_seq"'::regclass);


--
-- Name: Role user_role_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."Role" ALTER COLUMN user_role_id SET DEFAULT nextval('mox."Role_user_role_id_seq"'::regclass);


--
-- Name: RoleModule role_module_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."RoleModule" ALTER COLUMN role_module_id SET DEFAULT nextval('mox."RoleModule_role_module_id_seq"'::regclass);


--
-- Name: UserAccount user_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."UserAccount" ALTER COLUMN user_id SET DEFAULT nextval('mox."UserAccount_user_id_seq"'::regclass);


--
-- Name: UserAccountRole user_account_role_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."UserAccountRole" ALTER COLUMN user_account_role_id SET DEFAULT nextval('mox."UserAccountRole_user_account_role_id_seq"'::regclass);


--
-- Name: UserPids id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."UserPids" ALTER COLUMN id SET DEFAULT nextval('mox."UserPids_id_seq"'::regclass);


--
-- Name: audience audience_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.audience ALTER COLUMN audience_id SET DEFAULT nextval('mox.audience_audience_id_seq'::regclass);


--
-- Name: audience_fields field_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.audience_fields ALTER COLUMN field_id SET DEFAULT nextval('mox.audience_fields_field_id_seq'::regclass);


--
-- Name: brand brand_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.brand ALTER COLUMN brand_id SET DEFAULT nextval('mox.brand_brand_id_seq'::regclass);


--
-- Name: campaign campaign_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.campaign ALTER COLUMN campaign_id SET DEFAULT nextval('mox.campaign_campaign_id_seq'::regclass);


--
-- Name: campaign_fields field_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.campaign_fields ALTER COLUMN field_id SET DEFAULT nextval('mox.campaign_fields_field_id_seq'::regclass);


--
-- Name: location location_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.location ALTER COLUMN location_id SET DEFAULT nextval('mox.location_location_id_seq'::regclass);


--
-- Name: permission permission_id; Type: DEFAULT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.permission ALTER COLUMN permission_id SET DEFAULT nextval('mox.permission_permission_id_seq'::regclass);


--
-- Data for Name: BusinessCategories; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox."BusinessCategories" (business_category_id, business_category_name, created_at, updated_at) FROM stdin;
1	Attractions	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
2	Automotive	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
3	Books and Literature	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
4	Business and Finance	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
5	Careers	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
6	Communication	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
7	Crime	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
8	Disasters	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
9	Education	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
10	Entertainment	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
11	Events	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
12	Family and Relationships	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
13	Fine Art	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
14	Food & Drink	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
15	Genres	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
16	Healthy Living	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
17	Hobbies & Interests	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
18	Holidays	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
19	Home & Garden	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
20	Law	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
21	Maps & Navigation	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
22	Medical Health	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
23	Music	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
24	Personal Celebrations & Life Events	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
25	Personal Finance	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
26	Pets	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
27	Politics	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
28	Pop Culture	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
29	Productivity	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
30	Real Estate	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
31	Religion & Spirituality	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
32	Science	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
33	Sensitive Topics	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
34	Shopping	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
35	Sports	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
36	Style & Fashion	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
37	Technology & Computing	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
38	Travel	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
39	Video Gaming	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
40	War and Conflicts	2023-03-02 18:25:22.611	2023-03-02 18:25:22.611
\.


--
-- Data for Name: BusinessEntity; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox."BusinessEntity" (business_entity_id, business_entity_type_id, given_name, family_name, email, display_name, category, industry_type, created_at, updated_at) FROM stdin;
1	3	Jerry	Jerry	jerry@gmail.com	Kool Jerry	\N	\N	2023-01-11 06:15:37.81	2023-01-11 06:15:37.81
2	3	Tuktuk	Tuktuk	tuktuk@gmail.com	TukTuk Superstar	\N	\N	2023-01-11 06:16:08.634	2023-01-11 06:16:08.634
3	3	Stark	Howard Stark	stark@gmail.com	Iron Man	\N	\N	2023-01-11 06:17:57.675	2023-01-11 06:17:57.675
4	3	Jeff Bezos	Bezos	bezos@gmail.com	Amazon	\N	\N	2023-01-17 06:24:42.39	2023-01-17 06:24:42.39
5	3	Swiggy	Swiggy D	swiggy@gmail.com	Swiggy Delhivery	\N	\N	2023-01-23 07:01:31.962	2023-01-23 07:01:31.962
6	3	Zomato	Zomato D	zomato@gmail.com	Zomato Delivery	\N	\N	2023-01-23 07:02:23.016	2023-01-23 07:02:23.016
9	3	Seb	Sebastian	nikhil.upadhyay@prolitus.com	Sebastian Shultz	\N	\N	2023-02-28 10:43:23.203	2023-02-28 10:43:23.203
\.


--
-- Data for Name: BusinessEntityType; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox."BusinessEntityType" (business_entity_type_id, business_entity_type_name, description, created_at, updated_at) FROM stdin;
1	PROMOTION_PARTNER	Those who give data	2023-01-10 18:13:53.4	2023-01-10 18:13:53.4
2	MONETIZATION_PARTNER	Those who want to get data	2023-01-10 18:13:53.4	2023-01-10 18:13:53.4
3	BOTH	A User can be both Promotion and Monetization Partner	2023-01-10 18:13:53.4	2023-01-10 18:13:53.4
\.


--
-- Data for Name: CampaignCreatives; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox."CampaignCreatives" (creative_id, campaign_id, banner_type, banner_size, banner_format, url, created_at, updated_at) FROM stdin;
1	21	image	120*600	jpg	/uploads/creatives/1679995090431-ad34.jpg	2023-03-28 09:18:10.439	2023-03-28 09:18:10.439
2	21	video	600*400	mp4	/uploads/creatives/1679997081161-windmill.mp4	2023-03-28 09:51:21.174	2023-03-28 09:51:21.174
\.


--
-- Data for Name: ClientDBInfo; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox."ClientDBInfo" (id, business_entity_id, created_at, updated_at, brand_id, client_db_password, client_db_username, client_dbname) FROM stdin;
10	4	2023-03-06 07:48:08.897	2023-03-06 07:48:08.897	10	NIkhil@123$	postgres	amazon
11	5	2023-03-06 07:48:38.376	2023-03-06 07:48:38.376	11	NIkhil@123$	postgres	swiggy
12	6	2023-03-06 07:49:09.657	2023-03-06 07:49:09.657	9	NIkhil@123$	postgres	zomato
\.


--
-- Data for Name: ConnectionRequest; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox."ConnectionRequest" (request_id, "isAccepted", created_at, updated_at, "receiver_brandId", "receiver_userId", "sender_brandId", "sender_userId", "sender_campaignId", "requestStatus", dc_note, dp_note) FROM stdin;
13	f	2023-03-22 13:27:18.724	2023-03-22 13:27:18.724	10	4	12	2	19	REJECTED	\N	We can't share this type of confidential data
14	t	2023-04-05 08:02:44.928	2023-04-05 08:02:44.928	10	4	13	9	23	ACCEPTED	\N	accepted offer
\.


--
-- Data for Name: CountriesData; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox."CountriesData" (country_id, country_name, country_code, created_at, updated_at) FROM stdin;
1	Afghanistan	AF	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
2	Albania	AL	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
3	Algeria	DZ	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
4	Argentina	AR	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
5	Australia	AU	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
6	Austria	AT	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
7	Bangladesh	BD	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
8	Belarus	BY	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
9	Belgium	BE	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
10	Bhutan	BT	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
11	Brazil	BR	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
12	Canada	CA	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
13	Chile	CL	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
14	China	CN	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
15	Costa Rica	CR	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
16	Croatia	HR	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
17	Cuba	CU	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
18	Denmark	DK	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
19	Egypt	EG	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
20	Finland	FI	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
21	France	FR	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
22	Germany	DE	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
23	Ghana	GH	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
24	Greece	GR	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
25	Greenland	GL	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
26	Hongkong	HK	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
27	Hungary	HU	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
28	Iceland	IS	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
29	India	IN	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
30	Indonesia	ID	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
31	Iran	IR	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
32	Iraq	IQ	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
33	Ireland	IE	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
34	Israel	IL	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
35	Italy	IT	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
36	Japan	JP	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
37	Korea	KP	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
38	Kuwait	KW	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
39	Lebanon	LB	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
40	Libya	LY	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
41	Lithuania	LT	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
42	Luxembourg	LU	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
43	Malaysia	MY	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
44	Maldives	MV	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
45	Mauritius	MU	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
46	Mexico	MX	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
47	Montserrat	MS	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
48	Morocco	MA	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
49	Myanmar	MM	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
50	Namibia	NA	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
51	Nepal	NP	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
52	Netherlands	NL	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
53	New Zealand	NZ	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
54	Nigeria	NG	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
55	Norway	NO	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
56	Oman	OM	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
57	Pakistan	PK	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
58	Paraguay	PY	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
59	Philippines	PH	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
60	Poland	PL	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
61	Portugal	PT	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
62	Qatar	QA	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
63	Romania	RO	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
64	Rwanda	RW	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
65	Saudi Arabia	SA	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
66	Senegal	SN	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
67	Singapore	SG	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
68	South Africa	ZA	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
69	Spain	ES	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
70	Sweden	SE	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
71	Switzerland	CH	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
72	Thailand	TH	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
73	Ukraine	UA	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
74	United Arab Emirates	AE	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
75	United States of America	US	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
76	Uruguay	UY	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
77	Vietnam	VN	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
78	Egypt	EG	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
79	Zimbabwe	ZW	2023-03-03 16:21:45.529	2023-03-03 16:21:45.529
\.


--
-- Data for Name: DataProof; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox."DataProof" (proof_id, proof, solidity, pids, "contractAddress", created_at, "isVerified", updated_at, receiver_brand_id, receiver_business_entity_id, sender_brand_id, sender_business_entity_id, sender_campaign_id, users_count) FROM stdin;
16	{"curve": "bn128", "proof": {"a": ["0x006a9561c526241b8a5916e0129b577a24a74ee5728fce91a34934ba34564822", "0x030c9465e08c1f79f54acdd9e89e24e0e795ab262fb2870b290e0e311ed4287e"], "b": [["0x1587a307063cf1ccfb36095c41e07a25aa4f35f683a1f88b914083b21315f2b2", "0x14e5d00408c5999b77a5cc09283319f30c6a0629c8c01c83cb43e0e32660acd2"], ["0x0de9e88ca3b33f7f91cb6043ff6d3bdd6a8cb5d13f3c9f86f70b530b97a5ceca", "0x23c635443b73472f241636c6cc55fd5efac6e551e9ecb3c5243631435a9657e5"]], "c": ["0x02681b5c96bf05fd5df5ee939b4649a72e7c3705dc1195cde5696e6b09c41d1f", "0x0ade0c48294c3f0aec3cb705d521ec6dd7318673bdd58a991690544cf09876ec"]}, "inputs": ["0x0000000000000000000000000000000000000000000000000000000000000012", "0x000000000000000000000000000000000000000000000000000000000000002d", "0x000000000000000000000000000000000000000000000000000000000000004d", "0x00000000000000000000000000000000000000000000000000456e676c697368", "0x0000000000000000000000000000000000000000000000000000496e6469616e", "0x0000000000000000000000000000000042616861736120496e646f6e65736961", "0x00000000000000000000000000000000000000000000000000000000034271d9", "0x000000000000000000000000000000000000000000000000546861696c616e64", "0x000000000000000000000000000000000000000000000000000000496e646961", "0x0000000000000000000000000000000000000000000000496e646f6e65736961", "0x0000000000000000000000000000000000000000000000000000000000000001"], "scheme": "g16"}	Ly8gVGhpcyBmaWxlIGlzIE1JVCBMaWNlbnNlZC4KLy8KLy8gQ29weXJpZ2h0IDIwMTcgQ2hyaXN0aWFuIFJlaXR3aWVzc25lcgovLyBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYSBjb3B5IG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlICJTb2Z0d2FyZSIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmcgd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLCBjb3B5LCBtb2RpZnksIG1lcmdlLCBwdWJsaXNoLCBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG8gcGVybWl0IHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZSBmb2xsb3dpbmcgY29uZGl0aW9uczoKLy8gVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWQgaW4gYWxsIGNvcGllcyBvciBzdWJzdGFudGlhbCBwb3J0aW9ucyBvZiB0aGUgU29mdHdhcmUuCi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCAiQVMgSVMiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTIE9SIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0YgTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTiBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSwgREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRSBTT0ZUV0FSRSBPUiBUSEUgVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS4KcHJhZ21hIHNvbGlkaXR5IF4wLjguMDsKbGlicmFyeSBQYWlyaW5nIHsKICAgIHN0cnVjdCBHMVBvaW50IHsKICAgICAgICB1aW50IFg7CiAgICAgICAgdWludCBZOwogICAgfQogICAgLy8gRW5jb2Rpbmcgb2YgZmllbGQgZWxlbWVudHMgaXM6IFhbMF0gKiB6ICsgWFsxXQogICAgc3RydWN0IEcyUG9pbnQgewogICAgICAgIHVpbnRbMl0gWDsKICAgICAgICB1aW50WzJdIFk7CiAgICB9CiAgICAvLy8gQHJldHVybiB0aGUgZ2VuZXJhdG9yIG9mIEcxCiAgICBmdW5jdGlvbiBQMSgpIHB1cmUgaW50ZXJuYWwgcmV0dXJucyAoRzFQb2ludCBtZW1vcnkpIHsKICAgICAgICByZXR1cm4gRzFQb2ludCgxLCAyKTsKICAgIH0KICAgIC8vLyBAcmV0dXJuIHRoZSBnZW5lcmF0b3Igb2YgRzIKICAgIGZ1bmN0aW9uIFAyKCkgcHVyZSBpbnRlcm5hbCByZXR1cm5zIChHMlBvaW50IG1lbW9yeSkgewogICAgICAgIHJldHVybiBHMlBvaW50KAogICAgICAgICAgICBbMTA4NTcwNDY5OTkwMjMwNTcxMzU5NDQ1NzA3NjIyMzI4Mjk0ODEzNzA3NTYzNTk1Nzg1MTgwODY5OTA1MTk5OTMyODU2NTU4NTI3ODEsCiAgICAgICAgICAgICAxMTU1OTczMjAzMjk4NjM4NzEwNzk5MTAwNDAyMTM5MjI4NTc4MzkyNTgxMjg2MTgyMTE5MjUzMDkxNzQwMzE1MTQ1MjM5MTgwNTYzNF0sCiAgICAgICAgICAgIFs4NDk1NjUzOTIzMTIzNDMxNDE3NjA0OTczMjQ3NDg5MjcyNDM4NDE4MTkwNTg3MjYzNjAwMTQ4NzcwMjgwNjQ5MzA2OTU4MTAxOTMwLAogICAgICAgICAgICAgNDA4MjM2Nzg3NTg2MzQzMzY4MTMzMjIwMzQwMzE0NTQzNTU2ODMxNjg1MTMyNzU5MzQwMTIwODEwNTc0MTA3NjIxNDEyMDA5MzUzMV0KICAgICAgICApOwogICAgfQogICAgLy8vIEByZXR1cm4gdGhlIG5lZ2F0aW9uIG9mIHAsIGkuZS4gcC5hZGRpdGlvbihwLm5lZ2F0ZSgpKSBzaG91bGQgYmUgemVyby4KICAgIGZ1bmN0aW9uIG5lZ2F0ZShHMVBvaW50IG1lbW9yeSBwKSBwdXJlIGludGVybmFsIHJldHVybnMgKEcxUG9pbnQgbWVtb3J5KSB7CiAgICAgICAgLy8gVGhlIHByaW1lIHEgaW4gdGhlIGJhc2UgZmllbGQgRl9xIGZvciBHMQogICAgICAgIHVpbnQgcSA9IDIxODg4MjQyODcxODM5Mjc1MjIyMjQ2NDA1NzQ1MjU3Mjc1MDg4Njk2MzExMTU3Mjk3ODIzNjYyNjg5MDM3ODk0NjQ1MjI2MjA4NTgzOwogICAgICAgIGlmIChwLlggPT0gMCAmJiBwLlkgPT0gMCkKICAgICAgICAgICAgcmV0dXJuIEcxUG9pbnQoMCwgMCk7CiAgICAgICAgcmV0dXJuIEcxUG9pbnQocC5YLCBxIC0gKHAuWSAlIHEpKTsKICAgIH0KICAgIC8vLyBAcmV0dXJuIHIgdGhlIHN1bSBvZiB0d28gcG9pbnRzIG9mIEcxCiAgICBmdW5jdGlvbiBhZGRpdGlvbihHMVBvaW50IG1lbW9yeSBwMSwgRzFQb2ludCBtZW1vcnkgcDIpIGludGVybmFsIHZpZXcgcmV0dXJucyAoRzFQb2ludCBtZW1vcnkgcikgewogICAgICAgIHVpbnRbNF0gbWVtb3J5IGlucHV0OwogICAgICAgIGlucHV0WzBdID0gcDEuWDsKICAgICAgICBpbnB1dFsxXSA9IHAxLlk7CiAgICAgICAgaW5wdXRbMl0gPSBwMi5YOwogICAgICAgIGlucHV0WzNdID0gcDIuWTsKICAgICAgICBib29sIHN1Y2Nlc3M7CiAgICAgICAgYXNzZW1ibHkgewogICAgICAgICAgICBzdWNjZXNzIDo9IHN0YXRpY2NhbGwoc3ViKGdhcygpLCAyMDAwKSwgNiwgaW5wdXQsIDB4YzAsIHIsIDB4NjApCiAgICAgICAgICAgIC8vIFVzZSAiaW52YWxpZCIgdG8gbWFrZSBnYXMgZXN0aW1hdGlvbiB3b3JrCiAgICAgICAgICAgIHN3aXRjaCBzdWNjZXNzIGNhc2UgMCB7IGludmFsaWQoKSB9CiAgICAgICAgfQogICAgICAgIHJlcXVpcmUoc3VjY2Vzcyk7CiAgICB9CgoKICAgIC8vLyBAcmV0dXJuIHIgdGhlIHByb2R1Y3Qgb2YgYSBwb2ludCBvbiBHMSBhbmQgYSBzY2FsYXIsIGkuZS4KICAgIC8vLyBwID09IHAuc2NhbGFyX211bCgxKSBhbmQgcC5hZGRpdGlvbihwKSA9PSBwLnNjYWxhcl9tdWwoMikgZm9yIGFsbCBwb2ludHMgcC4KICAgIGZ1bmN0aW9uIHNjYWxhcl9tdWwoRzFQb2ludCBtZW1vcnkgcCwgdWludCBzKSBpbnRlcm5hbCB2aWV3IHJldHVybnMgKEcxUG9pbnQgbWVtb3J5IHIpIHsKICAgICAgICB1aW50WzNdIG1lbW9yeSBpbnB1dDsKICAgICAgICBpbnB1dFswXSA9IHAuWDsKICAgICAgICBpbnB1dFsxXSA9IHAuWTsKICAgICAgICBpbnB1dFsyXSA9IHM7CiAgICAgICAgYm9vbCBzdWNjZXNzOwogICAgICAgIGFzc2VtYmx5IHsKICAgICAgICAgICAgc3VjY2VzcyA6PSBzdGF0aWNjYWxsKHN1YihnYXMoKSwgMjAwMCksIDcsIGlucHV0LCAweDgwLCByLCAweDYwKQogICAgICAgICAgICAvLyBVc2UgImludmFsaWQiIHRvIG1ha2UgZ2FzIGVzdGltYXRpb24gd29yawogICAgICAgICAgICBzd2l0Y2ggc3VjY2VzcyBjYXNlIDAgeyBpbnZhbGlkKCkgfQogICAgICAgIH0KICAgICAgICByZXF1aXJlIChzdWNjZXNzKTsKICAgIH0KICAgIC8vLyBAcmV0dXJuIHRoZSByZXN1bHQgb2YgY29tcHV0aW5nIHRoZSBwYWlyaW5nIGNoZWNrCiAgICAvLy8gZShwMVswXSwgcDJbMF0pICogIC4uLi4gKiBlKHAxW25dLCBwMltuXSkgPT0gMQogICAgLy8vIEZvciBleGFtcGxlIHBhaXJpbmcoW1AxKCksIFAxKCkubmVnYXRlKCldLCBbUDIoKSwgUDIoKV0pIHNob3VsZAogICAgLy8vIHJldHVybiB0cnVlLgogICAgZnVuY3Rpb24gcGFpcmluZyhHMVBvaW50W10gbWVtb3J5IHAxLCBHMlBvaW50W10gbWVtb3J5IHAyKSBpbnRlcm5hbCB2aWV3IHJldHVybnMgKGJvb2wpIHsKICAgICAgICByZXF1aXJlKHAxLmxlbmd0aCA9PSBwMi5sZW5ndGgpOwogICAgICAgIHVpbnQgZWxlbWVudHMgPSBwMS5sZW5ndGg7CiAgICAgICAgdWludCBpbnB1dFNpemUgPSBlbGVtZW50cyAqIDY7CiAgICAgICAgdWludFtdIG1lbW9yeSBpbnB1dCA9IG5ldyB1aW50W10oaW5wdXRTaXplKTsKICAgICAgICBmb3IgKHVpbnQgaSA9IDA7IGkgPCBlbGVtZW50czsgaSsrKQogICAgICAgIHsKICAgICAgICAgICAgaW5wdXRbaSAqIDYgKyAwXSA9IHAxW2ldLlg7CiAgICAgICAgICAgIGlucHV0W2kgKiA2ICsgMV0gPSBwMVtpXS5ZOwogICAgICAgICAgICBpbnB1dFtpICogNiArIDJdID0gcDJbaV0uWFsxXTsKICAgICAgICAgICAgaW5wdXRbaSAqIDYgKyAzXSA9IHAyW2ldLlhbMF07CiAgICAgICAgICAgIGlucHV0W2kgKiA2ICsgNF0gPSBwMltpXS5ZWzFdOwogICAgICAgICAgICBpbnB1dFtpICogNiArIDVdID0gcDJbaV0uWVswXTsKICAgICAgICB9CiAgICAgICAgdWludFsxXSBtZW1vcnkgb3V0OwogICAgICAgIGJvb2wgc3VjY2VzczsKICAgICAgICBhc3NlbWJseSB7CiAgICAgICAgICAgIHN1Y2Nlc3MgOj0gc3RhdGljY2FsbChzdWIoZ2FzKCksIDIwMDApLCA4LCBhZGQoaW5wdXQsIDB4MjApLCBtdWwoaW5wdXRTaXplLCAweDIwKSwgb3V0LCAweDIwKQogICAgICAgICAgICAvLyBVc2UgImludmFsaWQiIHRvIG1ha2UgZ2FzIGVzdGltYXRpb24gd29yawogICAgICAgICAgICBzd2l0Y2ggc3VjY2VzcyBjYXNlIDAgeyBpbnZhbGlkKCkgfQogICAgICAgIH0KICAgICAgICByZXF1aXJlKHN1Y2Nlc3MpOwogICAgICAgIHJldHVybiBvdXRbMF0gIT0gMDsKICAgIH0KICAgIC8vLyBDb252ZW5pZW5jZSBtZXRob2QgZm9yIGEgcGFpcmluZyBjaGVjayBmb3IgdHdvIHBhaXJzLgogICAgZnVuY3Rpb24gcGFpcmluZ1Byb2QyKEcxUG9pbnQgbWVtb3J5IGExLCBHMlBvaW50IG1lbW9yeSBhMiwgRzFQb2ludCBtZW1vcnkgYjEsIEcyUG9pbnQgbWVtb3J5IGIyKSBpbnRlcm5hbCB2aWV3IHJldHVybnMgKGJvb2wpIHsKICAgICAgICBHMVBvaW50W10gbWVtb3J5IHAxID0gbmV3IEcxUG9pbnRbXSgyKTsKICAgICAgICBHMlBvaW50W10gbWVtb3J5IHAyID0gbmV3IEcyUG9pbnRbXSgyKTsKICAgICAgICBwMVswXSA9IGExOwogICAgICAgIHAxWzFdID0gYjE7CiAgICAgICAgcDJbMF0gPSBhMjsKICAgICAgICBwMlsxXSA9IGIyOwogICAgICAgIHJldHVybiBwYWlyaW5nKHAxLCBwMik7CiAgICB9CiAgICAvLy8gQ29udmVuaWVuY2UgbWV0aG9kIGZvciBhIHBhaXJpbmcgY2hlY2sgZm9yIHRocmVlIHBhaXJzLgogICAgZnVuY3Rpb24gcGFpcmluZ1Byb2QzKAogICAgICAgICAgICBHMVBvaW50IG1lbW9yeSBhMSwgRzJQb2ludCBtZW1vcnkgYTIsCiAgICAgICAgICAgIEcxUG9pbnQgbWVtb3J5IGIxLCBHMlBvaW50IG1lbW9yeSBiMiwKICAgICAgICAgICAgRzFQb2ludCBtZW1vcnkgYzEsIEcyUG9pbnQgbWVtb3J5IGMyCiAgICApIGludGVybmFsIHZpZXcgcmV0dXJucyAoYm9vbCkgewogICAgICAgIEcxUG9pbnRbXSBtZW1vcnkgcDEgPSBuZXcgRzFQb2ludFtdKDMpOwogICAgICAgIEcyUG9pbnRbXSBtZW1vcnkgcDIgPSBuZXcgRzJQb2ludFtdKDMpOwogICAgICAgIHAxWzBdID0gYTE7CiAgICAgICAgcDFbMV0gPSBiMTsKICAgICAgICBwMVsyXSA9IGMxOwogICAgICAgIHAyWzBdID0gYTI7CiAgICAgICAgcDJbMV0gPSBiMjsKICAgICAgICBwMlsyXSA9IGMyOwogICAgICAgIHJldHVybiBwYWlyaW5nKHAxLCBwMik7CiAgICB9CiAgICAvLy8gQ29udmVuaWVuY2UgbWV0aG9kIGZvciBhIHBhaXJpbmcgY2hlY2sgZm9yIGZvdXIgcGFpcnMuCiAgICBmdW5jdGlvbiBwYWlyaW5nUHJvZDQoCiAgICAgICAgICAgIEcxUG9pbnQgbWVtb3J5IGExLCBHMlBvaW50IG1lbW9yeSBhMiwKICAgICAgICAgICAgRzFQb2ludCBtZW1vcnkgYjEsIEcyUG9pbnQgbWVtb3J5IGIyLAogICAgICAgICAgICBHMVBvaW50IG1lbW9yeSBjMSwgRzJQb2ludCBtZW1vcnkgYzIsCiAgICAgICAgICAgIEcxUG9pbnQgbWVtb3J5IGQxLCBHMlBvaW50IG1lbW9yeSBkMgogICAgKSBpbnRlcm5hbCB2aWV3IHJldHVybnMgKGJvb2wpIHsKICAgICAgICBHMVBvaW50W10gbWVtb3J5IHAxID0gbmV3IEcxUG9pbnRbXSg0KTsKICAgICAgICBHMlBvaW50W10gbWVtb3J5IHAyID0gbmV3IEcyUG9pbnRbXSg0KTsKICAgICAgICBwMVswXSA9IGExOwogICAgICAgIHAxWzFdID0gYjE7CiAgICAgICAgcDFbMl0gPSBjMTsKICAgICAgICBwMVszXSA9IGQxOwogICAgICAgIHAyWzBdID0gYTI7CiAgICAgICAgcDJbMV0gPSBiMjsKICAgICAgICBwMlsyXSA9IGMyOwogICAgICAgIHAyWzNdID0gZDI7CiAgICAgICAgcmV0dXJuIHBhaXJpbmcocDEsIHAyKTsKICAgIH0KfQoKY29udHJhY3QgVmVyaWZpZXIgewogICAgdXNpbmcgUGFpcmluZyBmb3IgKjsKICAgIHN0cnVjdCBWZXJpZnlpbmdLZXkgewogICAgICAgIFBhaXJpbmcuRzFQb2ludCBhbHBoYTsKICAgICAgICBQYWlyaW5nLkcyUG9pbnQgYmV0YTsKICAgICAgICBQYWlyaW5nLkcyUG9pbnQgZ2FtbWE7CiAgICAgICAgUGFpcmluZy5HMlBvaW50IGRlbHRhOwogICAgICAgIFBhaXJpbmcuRzFQb2ludFtdIGdhbW1hX2FiYzsKICAgIH0KICAgIHN0cnVjdCBQcm9vZiB7CiAgICAgICAgUGFpcmluZy5HMVBvaW50IGE7CiAgICAgICAgUGFpcmluZy5HMlBvaW50IGI7CiAgICAgICAgUGFpcmluZy5HMVBvaW50IGM7CiAgICB9CiAgICBmdW5jdGlvbiB2ZXJpZnlpbmdLZXkoKSBwdXJlIGludGVybmFsIHJldHVybnMgKFZlcmlmeWluZ0tleSBtZW1vcnkgdmspIHsKICAgICAgICB2ay5hbHBoYSA9IFBhaXJpbmcuRzFQb2ludCh1aW50MjU2KDB4MTEwYmI3YjBhYmI3NWE0YWVkMjAyMDE2MzUyN2VhNzQ3Y2QyMjdjZGJhYzJkNjJkODZlNTlhMDY5OWRkOGIwOCksIHVpbnQyNTYoMHgyMzFjNzFlMzQxZDg1NjRkYTY1MzQ2NjkwODQ4YTQ4NzFlZGU5YTQyYjRlNjM2MjhlY2Q2YWM0ZTg5YmYyMTlhKSk7CiAgICAgICAgdmsuYmV0YSA9IFBhaXJpbmcuRzJQb2ludChbdWludDI1NigweDE5Y2M1YmM1Njk1MzA4ODcwYjg1NzRhNGRlZmNmMTU4MjkzZDE5ZWVjMzdjNzlkY2NjMjEyODkwMjZlMDRmY2IpLCB1aW50MjU2KDB4MWJhZTcyNGZkOGY0NWMxMGRkNmUwNTM1YWNjNjM1ZTAxNDBmMjIxNTE1ZjliYzFiYTA3ZjkyMTkwODkwMzlkNCldLCBbdWludDI1NigweDJhMGU2NjFjYmJjNDBiMDZmY2U3NTYxNzVkMmZlYzM1ZDcxZTQwYzQ4ODQ0NGU5NTdkNTI4ODU2MjhmNjAwZTEpLCB1aW50MjU2KDB4MDFmNjZhNGNkZWM2MjkzMTQ3YWNiNGM0ZmE5MDFjZTFhZTViZmJhNTEwNGRkNWY1ZWI5MjNlMjg5MWIwM2ZhMildKTsKICAgICAgICB2ay5nYW1tYSA9IFBhaXJpbmcuRzJQb2ludChbdWludDI1NigweDFmZThlYzlmZTUzNDQyMzlmNmEwYjYzNjhlNjQ2MjY3MjBjNGI0N2M0NWYzYzVkZWVmODRlOTNjMjA5NzcxYzApLCB1aW50MjU2KDB4MmViZWYyY2ZkNWU3MDIyZjk4NmMyMjkxZTkyYzllNzRjMTRmNDZhZGRiZDhlMjQwNWIwOTY4ZGEyMGM5NjFiNSldLCBbdWludDI1NigweDA4NmJlYWY4NGViM2I5YzVhMDkyMWFiM2VhNzczMDllNjVlYTdlMzNjMTJhNmViOTUzNjFjY2FkZTgxN2QxZmMpLCB1aW50MjU2KDB4MjlkYjU0OTRjMjhkNThkMzkwODlkZWExZmQ3M2ZkZTBhMDI3YWViYTc1Y2E0ZWE1NGExNjVkNDIzZmRjMGQzNildKTsKICAgICAgICB2ay5kZWx0YSA9IFBhaXJpbmcuRzJQb2ludChbdWludDI1NigweDA2OTkzZmE4YWQyYTczMDMxYWI0ZTI5NjQ3NmExOWE2NTgyNTAzY2U0YWU4NWVlNjYzMjkzODlhZTUzYTBmNWUpLCB1aW50MjU2KDB4MWNjZGNhYjQ4MWEwMzgwNDczMmI1NjU3NDA4Zjc0Y2Q1MjYyZTU1NTVlZWI3ZWY0OTk1MjQyZGNiODExMTc1ZildLCBbdWludDI1NigweDBiMDE0ODJjY2Q3YjBiNmIzYzAxNjhmMWRkODMwNjcxZjlhY2U4ZDc4NDk0ODVkMmM3NWY3NDRiMmM2ZjZiNDIpLCB1aW50MjU2KDB4MjllNDYxNzI5MGI2MGQyYmI0YmNhYzU5YWUzNGY1ODk2N2FkMzI3NDdmOGRjOWUwNTQzNGUyM2YyZjJkMTU5NildKTsKICAgICAgICB2ay5nYW1tYV9hYmMgPSBuZXcgUGFpcmluZy5HMVBvaW50W10oMTIpOwogICAgICAgIHZrLmdhbW1hX2FiY1swXSA9IFBhaXJpbmcuRzFQb2ludCh1aW50MjU2KDB4MGQyMTAxYmM2ZTVlYTQwZmQ4NTcxMjI0N2FjZjkxMWJkYzg5ZDgwMGMxYmZjNDE4ZTdiMGYzNzBjYmFlYzhmOSksIHVpbnQyNTYoMHgxYWIwOWFiOTc0NzcyNWY4NDgzMDRlNTE5YWViMWYyMGU1MmI5MmNmMjAzMTgxYmFkMDIzOTZiOTMxZTU1YmJiKSk7CiAgICAgICAgdmsuZ2FtbWFfYWJjWzFdID0gUGFpcmluZy5HMVBvaW50KHVpbnQyNTYoMHgyY2VhOTk2NzY4Y2NlMmY2YWZhNDRjZTlhZmJjNmFiOGYwMzZjMGEyYzEwM2I4YWU2NjFmZmYyNzhmYWU2NjBjKSwgdWludDI1NigweDExOGY2Y2Q4Y2MwM2Q0MWQ4ZWZhZTlmNjc3ZTlkYjA3MzA0OWMxNDQ0MTE2OTExNjk5NzdkZGRiMTAyMDU0ZTIpKTsKICAgICAgICB2ay5nYW1tYV9hYmNbMl0gPSBQYWlyaW5nLkcxUG9pbnQodWludDI1NigweDE4YTMyNjNjM2MxMWYzYmY0ZjgxMmJlNzkxZDc0OTVmMWQ0M2JjZTdkNjM0ZGIxZDU2YzI5NDBhMDgyNTg5NGEpLCB1aW50MjU2KDB4MGQxMDg5MDA0ODM5Y2YwZWRiOTNmZjI2MGE0YWYwODNmZGVhMDFkZWI0YTNmODUxNTIwNGE2YzkwZDcxZGNkYikpOwogICAgICAgIHZrLmdhbW1hX2FiY1szXSA9IFBhaXJpbmcuRzFQb2ludCh1aW50MjU2KDB4MTVhNmM5YjExNmZhYTRhMTE2M2RlNmI5M2ZiMjg5ZGY3NDhiNjNiYzMzNDAyZjNhNzljMmZhNGUzNjRlY2U5ZiksIHVpbnQyNTYoMHgwYjI1OTUxMDI2M2NkZmVjZjI5OTM4ZmE1MDZiMDgxNjFkOGY2ZTVhZWE0YzhiZGYxZTBkYzk2YWRmNzg5YTI3KSk7CiAgICAgICAgdmsuZ2FtbWFfYWJjWzRdID0gUGFpcmluZy5HMVBvaW50KHVpbnQyNTYoMHgwNzE3NDYwNjk4MDgyODcyNzUwY2Y5NzA5MDA4ZjEzNjQ2OTk5NWRiMDczMmJjOTEzNTdiNzdjZjg3NzQyYTVkKSwgdWludDI1NigweDBkNmI0ZmE0MmE2MTE4ODNlNzM0NDU1YjZmZGVmMGRhYjllNWNkODlhY2RkNTg1OGMzYzk1ZWVkMjIxNTlkNWEpKTsKICAgICAgICB2ay5nYW1tYV9hYmNbNV0gPSBQYWlyaW5nLkcxUG9pbnQodWludDI1NigweDE3NTJhMDk0YmJhNWEyMjhiMjA4ZGE0ZDgxMTFiZGNkYjczZjAwOTQ5MWU5NGViMWY1ZTE1ZDkwNzAyMzJkZTQpLCB1aW50MjU2KDB4MGM1ZmFlNTVkYmM5NDNhZTgwYzViMTc5MzRkYThmYjk1NmM1ZDM5NWYxNjk0MjA2YmU1ODIxZWU1NWY0MTQ0YSkpOwogICAgICAgIHZrLmdhbW1hX2FiY1s2XSA9IFBhaXJpbmcuRzFQb2ludCh1aW50MjU2KDB4MTQyYWVjNjcyOWE0Mjg3YWM4MGFjYWUwMDUwN2VjY2UyMDI2NDg5NjE5ZmQ1YWY1ODk5YjEyMTM1NWI1ZmFhNCksIHVpbnQyNTYoMHgwZDNlY2VmM2JlOTg0M2IwYWJiMTM5Nzk0ZThkYmY4MWVhZDUwNDU0MTY3MmI2Mjc2MGZiYWE0MGU5MTFiOTliKSk7CiAgICAgICAgdmsuZ2FtbWFfYWJjWzddID0gUGFpcmluZy5HMVBvaW50KHVpbnQyNTYoMHgyMTIwZGI3Mjk0YmFiMDk1NDQxM2M4MTVlNmUyYWFiNDcxNDVmZjMyMzU2YmE1ZTg4YmFmNzQzMjM1OTQxOTMwKSwgdWludDI1NigweDBmNTI5NjM4ZWQ5MmNjMWJkYjczNDgyYjMwMmRiODM4YmJhYTczOWM1MTRkMWIwYTNhZjYwOTQyODEyMzA0ZDMpKTsKICAgICAgICB2ay5nYW1tYV9hYmNbOF0gPSBQYWlyaW5nLkcxUG9pbnQodWludDI1NigweDIxODljZmViNTA0YTMzNjFmMzcxZDg3MWMwOTFkMWVjN2E3YmExZWVhMWY3YWE1OTM5NTA1NGI4YjY3ZWI1M2EpLCB1aW50MjU2KDB4MGRhZGU0ZDQwZTM1YTdmZTMzYWEzYzA1OWQ2NzU4ZWE0M2ZlYzQ3NzU3M2Y1OWMzN2I3OWM5NWI4ZjcwZTMxYykpOwogICAgICAgIHZrLmdhbW1hX2FiY1s5XSA9IFBhaXJpbmcuRzFQb2ludCh1aW50MjU2KDB4MGVjMzcwODIyNjAwNjVhYTU1Y2U4NDY4MmFjNWRhZDdjNWM4OGExM2NlNGRhZTY5MjAxMjllMzVhMmY3M2EwZSksIHVpbnQyNTYoMHgyMzg1MTU4ZGU4YjY0NGQ4Yjk0MzBjNTJlZDFmODc3YWQ0NDllMzFiMWE0ODE3NGQ2YTUwODAzNDU2MzczYzRhKSk7CiAgICAgICAgdmsuZ2FtbWFfYWJjWzEwXSA9IFBhaXJpbmcuRzFQb2ludCh1aW50MjU2KDB4MDI1NGM5ZGVlZTllOTZmNGQ0MmNkOTZkYTRkY2U4NzEzYjg1YzBlNWI3MDVhNDdkYjFhODgwNDFiYjI3MDc3ZCksIHVpbnQyNTYoMHgwZjgwMDI0MzgzZTNiZjgyMjliMzVlZDBiZjZjNDg1OTRmYWQ4ODFmZjAxNTFlODcyNjdjN2ViYzNmODNiZDBhKSk7CiAgICAgICAgdmsuZ2FtbWFfYWJjWzExXSA9IFBhaXJpbmcuRzFQb2ludCh1aW50MjU2KDB4MTA5ODQzZDdjYTdiY2U4ODJlOTM1MDJmNzBlYTI3ZTFjNjEwYmQyMDM4N2NhMDRjNzhkZjgxNDk5MTRhZjdjOCksIHVpbnQyNTYoMHgyOTU2NTk1NDQwZDdhMzlmMDEzYTU4YjUyOGJhNzA1NTEzYjE1MjQ2MWQ0NmExMDNjOWM5YzUwMTg3ZDAwMmFjKSk7CiAgICB9CiAgICBmdW5jdGlvbiB2ZXJpZnkodWludFtdIG1lbW9yeSBpbnB1dCwgUHJvb2YgbWVtb3J5IHByb29mKSBpbnRlcm5hbCB2aWV3IHJldHVybnMgKHVpbnQpIHsKICAgICAgICB1aW50MjU2IHNuYXJrX3NjYWxhcl9maWVsZCA9IDIxODg4MjQyODcxODM5Mjc1MjIyMjQ2NDA1NzQ1MjU3Mjc1MDg4NTQ4MzY0NDAwNDE2MDM0MzQzNjk4MjA0MTg2NTc1ODA4NDk1NjE3OwogICAgICAgIFZlcmlmeWluZ0tleSBtZW1vcnkgdmsgPSB2ZXJpZnlpbmdLZXkoKTsKICAgICAgICByZXF1aXJlKGlucHV0Lmxlbmd0aCArIDEgPT0gdmsuZ2FtbWFfYWJjLmxlbmd0aCk7CiAgICAgICAgLy8gQ29tcHV0ZSB0aGUgbGluZWFyIGNvbWJpbmF0aW9uIHZrX3gKICAgICAgICBQYWlyaW5nLkcxUG9pbnQgbWVtb3J5IHZrX3ggPSBQYWlyaW5nLkcxUG9pbnQoMCwgMCk7CiAgICAgICAgZm9yICh1aW50IGkgPSAwOyBpIDwgaW5wdXQubGVuZ3RoOyBpKyspIHsKICAgICAgICAgICAgcmVxdWlyZShpbnB1dFtpXSA8IHNuYXJrX3NjYWxhcl9maWVsZCk7CiAgICAgICAgICAgIHZrX3ggPSBQYWlyaW5nLmFkZGl0aW9uKHZrX3gsIFBhaXJpbmcuc2NhbGFyX211bCh2ay5nYW1tYV9hYmNbaSArIDFdLCBpbnB1dFtpXSkpOwogICAgICAgIH0KICAgICAgICB2a194ID0gUGFpcmluZy5hZGRpdGlvbih2a194LCB2ay5nYW1tYV9hYmNbMF0pOwogICAgICAgIGlmKCFQYWlyaW5nLnBhaXJpbmdQcm9kNCgKICAgICAgICAgICAgIHByb29mLmEsIHByb29mLmIsCiAgICAgICAgICAgICBQYWlyaW5nLm5lZ2F0ZSh2a194KSwgdmsuZ2FtbWEsCiAgICAgICAgICAgICBQYWlyaW5nLm5lZ2F0ZShwcm9vZi5jKSwgdmsuZGVsdGEsCiAgICAgICAgICAgICBQYWlyaW5nLm5lZ2F0ZSh2ay5hbHBoYSksIHZrLmJldGEpKSByZXR1cm4gMTsKICAgICAgICByZXR1cm4gMDsKICAgIH0KICAgIGZ1bmN0aW9uIHZlcmlmeVR4KAogICAgICAgICAgICBQcm9vZiBtZW1vcnkgcHJvb2YsIHVpbnRbMTFdIG1lbW9yeSBpbnB1dAogICAgICAgICkgcHVibGljIHZpZXcgcmV0dXJucyAoYm9vbCByKSB7CiAgICAgICAgdWludFtdIG1lbW9yeSBpbnB1dFZhbHVlcyA9IG5ldyB1aW50W10oMTEpOwogICAgICAgIAogICAgICAgIGZvcih1aW50IGkgPSAwOyBpIDwgaW5wdXQubGVuZ3RoOyBpKyspewogICAgICAgICAgICBpbnB1dFZhbHVlc1tpXSA9IGlucHV0W2ldOwogICAgICAgIH0KICAgICAgICBpZiAodmVyaWZ5KGlucHV0VmFsdWVzLCBwcm9vZikgPT0gMCkgewogICAgICAgICAgICByZXR1cm4gdHJ1ZTsKICAgICAgICB9IGVsc2UgewogICAgICAgICAgICByZXR1cm4gZmFsc2U7CiAgICAgICAgfQogICAgfQp9Cg==	["53b199a172fdda22656f50f2cef3b084d4307778dd76692471f75eb5b9ce996b", "5e8cf632fbf87c831168fe59dd4e689cc03bb537b18db5013f42448d83740c58", "85c5fe545e50f271c0ce8344acb2d3c47a57b6e1e6f9a7fafe2320226b1e71f9", "8d5ae8e7c54f810ed8bf5481f9e504a2c2c0157131aafbf9a26ab1b63356a80a", "8d73a92119201b14c97533973811ef8f5bdede839b5c30b514fe887b5c1fa006", "a581e26a9dac49a9be4c7c5dca11f5631f837087ba630481be0f20a523a0d4cf", "cc30908a7ba470fd6a00d3906d709a685cbfc559085932218aca24b53b0cb47b", "d27f31c0a6485099af0809acc5db2911855f68d66bfd0d6dd7e0b867c6d2b084", "d2d06d4c2b4b83300c582989b249d8412eae2b017c3f01ca430af98b6e2ff362", "e976e04bedd98d59680464b0b501f3157c910c36ff9d073147c1a1b7f110da8c"]	\N	2023-04-12 08:56:57.953	f	2023-04-12 08:56:57.953	10	4	13	9	23	10
\.


--
-- Data for Name: FieldMapping; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox."FieldMapping" (id, field_name, amazon, swiggy, zomato, myntra, velocity) FROM stdin;
1	audience_location	"location"	"location"	"location"	"user_location"	\N
5	languages	"language"	"language"	"language"	null	\N
4	gender	"gender"	"gender"	"gender"	null	"owner_gender"
2	age_range_min	"age"	"age"	"age"	"user_age"	"owner_age"
3	age_range_max	"age"	"age"	"age"	"user_age"	"owner_age"
6	rc_rto_state	\N	\N	\N	\N	"rc_rto_state"
7	make_year	\N	\N	\N	\N	"make_year"
\.


--
-- Data for Name: Languages; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox."Languages" (language_id, language_name, language_code, created_at, updated_at) FROM stdin;
1	Arabic	AR	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
2	Bulgarian	BG	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
3	Catalan	CA	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
4	Chinese	CH	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
5	Croatian	HR	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
6	Czech	CS	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
7	Danish	DA	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
8	English	EN	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
9	French	FR	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
10	German	DE	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
11	Catalan	CA	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
12	Indonesian	ID	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
13	Irish	GA	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
14	Italian	IT	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
15	Japanese	JA	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
16	Korean	KO	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
17	Lituanian	LT	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
18	Portuguese	PT	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
19	Polish	PL	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
20	Russian	RU	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
21	Spanish	ES	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
22	Thai	TH	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
23	Vietnamese	VI	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
24	Catalan	CA	2023-03-03 20:29:11.809	2023-03-03 20:29:11.809
\.


--
-- Data for Name: Module; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox."Module" (module_id, module_name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: Role; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox."Role" (user_role_id, user_role_name, description, role_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: RoleModule; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox."RoleModule" (role_module_id, user_role_id, module_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: UserAccount; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox."UserAccount" (user_id, email, password_hash, password_salt, business_entity_id, login_as, is_active, is_email_verified, created_at, updated_at, p_id, code, "resetToken", role_name, account_status) FROM stdin;
4	bezos@gmail.com	a574ab7ffff332fcee4b4a9db79e8b422765565d53429027d0d7c456facfadb6926d241e9bb382138a63ed35234e36f781ebb5593237c98538302c7ca8b74c9e	ae4fbe8ca773e6c003b192f8d81fd2d1a3fc1a68a859ae67702b4ca950fb4ed0	4	2	\N	t	2023-01-17 06:24:42.404	2023-01-17 06:24:42.404	9ef214cb0347f6bbc38d055d0da314ff50f168753b3faf7ccb263fc5979809fe	\N	\N	NORMAL_USER	0
9	nikhil.upadhyay@prolitus.com	073806a01fb797d88b8e1ce5b5752108085cbbcaa5c80fdf815a7581d78526e7273d8c2f1934b299004c3f1cc3d5b0a6b4c1f922c90fb2287426aca057cca174	77ab26dab130d4b63caf1583815ebd7cbc5ad6b55360aa251f8d36ca9459a1dd	9	2	\N	t	2023-02-28 10:43:23.229	2023-02-28 10:43:23.229	b5385b27efc96431f8682cd475a82e2d44900f0ca4d875a7c83518c1e067fcb7	jsz3h5US	k1vzbBKY	NORMAL_USER	0
1	jerry@gmail.com	c36f18895ef3ff36b4db9761bcb3d5f0cbc0a498b1f0530ce40838d77f08f12b8b2f70d8688df6411be72fcfc2ef46157f80f5afe9f43793d1c6811732c7ec54	c0ee9485e1286b898e4355261c6c63a68c89ede5812fb469132b5d4d69cc000a	2	2	\N	t	2023-01-11 06:15:37.825	2023-01-11 06:15:37.825	6147dfecdcd5449a53885004df275194ecae32b6fe012cff231bcdfb7fb573de	\N	\N	NORMAL_USER	0
2	tuktuk@gmail.com	0ad2917311f669a9db469fec0f38f896660275ce0bcd476b00f341b200e1a6ba5f3fe885498b499a62623ffed7bc183fd3e1640d1caf007451aedf4b4d76cbe1	d29a5fddfbf4407c7be62f5cfdfd613c9dd606059fa8783170924fad7e0b1054	2	2	\N	t	2023-01-11 06:16:08.651	2023-01-11 06:16:08.651	c13b980bd227e95054e423a10287f58237fafaae9b636774e95093a5fff0ba5c	\N	\N	NORMAL_USER	0
3	stark@gmail.com	f0fec687e8ee2c167ac9b841a274be0e123a658a4dead6298f2e017ce2837726b232857534697db2be746841581671b8cf10967e4f5111380828d806ee0c55fa	4a89f0a3260b4e044c158ba1e5978550da7830d3e9f9ac7fd2394bb699de420c	3	2	\N	t	2023-01-11 06:17:57.687	2023-01-11 06:17:57.687	23e2305409b42be5abbfbb5d8d2e88e29cbb9d26a14e42461e60dd542df05840	\N	\N	NORMAL_USER	0
5	swiggy@gmail.com	a60fd14a028d523e116817a5c2cc01fc8d35c7945b7270335b963fbacc0cf1eebf5b2aea7a375c2b26eff01994cfbde4128166d4ce167de180da6455b5b67d9e	839ac989b9b9adafd703ca55623ef92d0c45224039693f788a02be0e4e3b295e	5	2	\N	t	2023-01-23 07:01:31.998	2023-01-23 07:01:31.998	7a69034af076dd003c8481d2e510fa48c79bbad06c80b302090373fd7fd02d76	\N	\N	NORMAL_USER	0
6	zomato@gmail.com	d01974411915038f67445d3b8c61ea447033b1dd62b35f6a12b681957fd00ff07adc868e4692b8ac61802ac227bc0a221ab3806cca34f05ac863247e734c009b	2462d6bd5bec5da4cfe21d0bc0b77b532de4fb16d625331d6ee708c0d5ba0ecf	6	2	\N	t	2023-01-23 07:02:23.031	2023-01-23 07:02:23.031	28628ec8153ef51c7b37cb2e9ae376f8f8de3621191f5de4b11723dc2d37af73	\N	\N	NORMAL_USER	0
\.


--
-- Data for Name: UserAccountRole; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox."UserAccountRole" (user_account_role_id, user_id, user_role_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: UserPids; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox."UserPids" (id, sender_business_entity_id, sender_brand_id, sender_campaign_id, receiver_business_entity_id, receiver_brand_id, p_id, created_at, updated_at) FROM stdin;
75	9	13	23	4	10	53b199a172fdda22656f50f2cef3b084d4307778dd76692471f75eb5b9ce996b	2023-04-12 08:56:57.972	2023-04-12 08:56:57.972
76	9	13	23	4	10	8d73a92119201b14c97533973811ef8f5bdede839b5c30b514fe887b5c1fa006	2023-04-12 08:56:57.98	2023-04-12 08:56:57.98
77	9	13	23	4	10	a581e26a9dac49a9be4c7c5dca11f5631f837087ba630481be0f20a523a0d4cf	2023-04-12 08:56:58.039	2023-04-12 08:56:58.039
78	9	13	23	4	10	cc30908a7ba470fd6a00d3906d709a685cbfc559085932218aca24b53b0cb47b	2023-04-12 08:56:58.04	2023-04-12 08:56:58.04
79	9	13	23	4	10	d27f31c0a6485099af0809acc5db2911855f68d66bfd0d6dd7e0b867c6d2b084	2023-04-12 08:56:58.04	2023-04-12 08:56:58.04
80	9	13	23	4	10	d2d06d4c2b4b83300c582989b249d8412eae2b017c3f01ca430af98b6e2ff362	2023-04-12 08:56:58.04	2023-04-12 08:56:58.04
81	9	13	23	4	10	e976e04bedd98d59680464b0b501f3157c910c36ff9d073147c1a1b7f110da8c	2023-04-12 08:56:58.04	2023-04-12 08:56:58.04
82	9	13	23	4	10	5e8cf632fbf87c831168fe59dd4e689cc03bb537b18db5013f42448d83740c58	2023-04-12 08:56:57.972	2023-04-12 08:56:57.972
83	9	13	23	4	10	85c5fe545e50f271c0ce8344acb2d3c47a57b6e1e6f9a7fafe2320226b1e71f9	2023-04-12 08:56:57.972	2023-04-12 08:56:57.972
84	9	13	23	4	10	8d5ae8e7c54f810ed8bf5481f9e504a2c2c0157131aafbf9a26ab1b63356a80a	2023-04-12 08:56:57.98	2023-04-12 08:56:57.98
\.


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
fc7267e6-daed-496d-ad5f-8e8223661fca	33f1c15d3e3800ae07dc8a8d1a5176d91548d5761f75de1afe569505b3a75ef0	2023-01-10 17:26:58.500702+05:30	20221214080437_init	\N	\N	2023-01-10 17:26:58.442567+05:30	1
94eb8d25-f24e-455e-b775-8199c904db6e	1dd1c684fe2b97fc8e478f965227f70fe71a27d6d6bf29052e430c0d37343de5	2023-01-10 17:26:58.646709+05:30	20230103122859_init	\N	\N	2023-01-10 17:26:58.640926+05:30	1
f9dd7bb9-ea70-426c-ae62-1717d51be0c8	e9db00327a3dcee143fb6e7f6ad5b6e74406ab9ddf7428dc8812a62de0b5d8ac	2023-01-10 17:26:58.506875+05:30	20221220064107_init	\N	\N	2023-01-10 17:26:58.502011+05:30	1
db518781-fcef-46c1-8195-910ae1c51fe6	25ddf5bec44d509df4f4a7c8b70ca48d63a185742b888c2a3fbff0a4f38c770f	2023-01-10 17:26:58.515128+05:30	20221220070948_init	\N	\N	2023-01-10 17:26:58.508138+05:30	1
d26d7638-274d-406e-874e-5f1097c378df	e4465ccabd4aaef159beca7d9c830a5e442dffcfe8a3b68cc3e356ecb0caf23b	2023-01-23 11:58:30.210606+05:30	20230123062830_init	\N	\N	2023-01-23 11:58:30.202382+05:30	1
6635f3d5-6dde-4ea5-9d7c-c5197e0c733e	f26d85f102d0e36ebf1ade28150f51a08f610b6f0f78015e0f74f3e9d74d09eb	2023-01-10 17:26:58.521713+05:30	20221220074144_init	\N	\N	2023-01-10 17:26:58.516566+05:30	1
0299914c-5d4a-4e27-b002-f508babab491	0b8604f1dcf5457af88a2102548e7d676ca5e53d6dbdd428a491bc6424163dcb	2023-01-10 17:26:58.658271+05:30	20230105112441_init	\N	\N	2023-01-10 17:26:58.64808+05:30	1
da007e42-996d-4cf4-9a60-f4745cbf0496	fc28359a60fbd48f1fa63335167143720d38054b47f94c2779b14ead1f98f5f6	2023-01-10 17:26:58.559018+05:30	20221221075712_init	\N	\N	2023-01-10 17:26:58.523131+05:30	1
aef3633b-37a8-4750-a141-e989d9bd7818	ca048b711afcbcd19ceca6c0d2d08ff37e315dd59c9156763f5d1c954a0dbd41	2023-01-10 17:26:58.565182+05:30	20221222074014_init	\N	\N	2023-01-10 17:26:58.560441+05:30	1
902d8a83-a001-479c-a64c-89d15aad7c0d	1fb51f531b99a17e029e69347601e8ea2479451cf3b34e83308a2616b10911d5	2023-01-10 17:26:58.571281+05:30	20221223054934_init	\N	\N	2023-01-10 17:26:58.566532+05:30	1
e6370734-974c-4fb3-b540-426aafb6ef88	50845d4a3601cec06a6f9a859b5f88c57a36ac54eb142345e53607db81231ecc	2023-01-10 17:26:58.679944+05:30	20230109214049_init	\N	\N	2023-01-10 17:26:58.659742+05:30	1
71d1862a-7e92-4477-bcda-c24b7e531943	8ab9b258a9c7d18eaafec41591c441c8db16ef5ce13354d114d5eefaab1f1f25	2023-01-10 17:26:58.582142+05:30	20221223083850_init	\N	\N	2023-01-10 17:26:58.572689+05:30	1
43f14776-19b3-4533-a6e6-abc61c0ab117	6d6b6f840a6bf1535d5c6946cc0fc8a467a8189ce5e43614d1145081c8c35252	2023-01-10 17:26:58.590425+05:30	20221223085002_init	\N	\N	2023-01-10 17:26:58.583465+05:30	1
1e4c23d5-bf40-4e22-bb2c-21c2a0ff9662	dcac4538048eefd505c7429c1f0db6cad07ee576e156f7ff2b80c46acb2966b2	2023-01-10 17:26:58.596751+05:30	20221226125150_init	\N	\N	2023-01-10 17:26:58.592125+05:30	1
803a27bb-fb71-4ad8-8d34-b8dce7cd7810	964caff68d7dae92a68e7fc38a930ab53d0572954a72e4cbd3daf8a068b540e3	2023-01-10 17:26:59.677034+05:30	20230110115659_init	\N	\N	2023-01-10 17:26:59.670069+05:30	1
4484bd3b-b44e-4dc9-8eac-b1c3d5e8f7bc	b452d98e9796bbab4fb27f6c767f01a0068daffeeea371aaafcb873f71bb028a	2023-01-10 17:26:58.607+05:30	20221227112448_init	\N	\N	2023-01-10 17:26:58.598228+05:30	1
e757b4f7-8b25-42f9-80c3-87a67a7b659b	22be783e970bc491f1b0c2ed90f2735ec40ec27ea642f76211ebbfa98a5753fe	2023-01-10 17:26:58.623502+05:30	20221227144622_init	\N	\N	2023-01-10 17:26:58.608415+05:30	1
673888cf-ecb3-48a9-ab6e-4220ea82443f	93089b1e2545a4e49d431421fbbabd9a836f726ea79d7114040eaced7c06a165	2023-01-26 13:19:44.5417+05:30	20230126074944_init	\N	\N	2023-01-26 13:19:44.52689+05:30	1
1aace0a5-b31a-41eb-a8d8-20c73fa88dfb	578f1421aa988ea3a928a1764b15cf3f3477db3b9645ea89b510a058117e4f5c	2023-01-10 17:26:58.633084+05:30	20230102153714_init	\N	\N	2023-01-10 17:26:58.625176+05:30	1
611254b2-27fc-48b7-a582-d2eeeda06085	77b45789adc1563b1e421a5cf7844785ee6fd256addb24de6a115291d0f1a947	2023-01-17 02:32:29.3919+05:30	20230116210229_init	\N	\N	2023-01-17 02:32:29.365429+05:30	1
0de06b68-9cb5-461b-83fa-345f06228768	6135de0d684e1855ade87d55bb14982dd40adbd92194524d3940ec583be83eca	2023-01-10 17:26:58.639619+05:30	20230103101557_init	\N	\N	2023-01-10 17:26:58.634753+05:30	1
96b2199f-4448-4134-8b8b-e2b54d10913e	a8d2ba1af6c0e1e427fb5cb28e50654cce1cade14b2aed109559b37bc8bb84d1	2023-01-18 00:10:38.443919+05:30	20230117184038_init	\N	\N	2023-01-18 00:10:38.438395+05:30	1
5de6c13c-c594-456b-9ad7-fa2acb360b84	8f0f8f756206850e1e7a5d0e538972a5a127fd3b4c9f92999bd29af068d03e49	2023-01-30 19:43:23.444606+05:30	20230130141323_init	\N	\N	2023-01-30 19:43:23.42865+05:30	1
dc58abd2-0b32-42ab-990b-acea13625658	affd8466338b2f170b791ae3cbe6a27cce67b969b5d8590ae85e0fc568eecd0c	2023-01-19 10:50:08.624867+05:30	20230119052008_init	\N	\N	2023-01-19 10:50:08.618492+05:30	1
d0dffe3e-f019-40f7-aff5-1162ad1a84d0	5cbb6be95b074cfbf4b35c3c0d355c4199368a370d0c1cb82d04daa1463be2b0	2023-01-27 11:41:03.905335+05:30	20230127061103_init	\N	\N	2023-01-27 11:41:03.877516+05:30	1
60683c9b-dd89-495a-8da9-895716b6d24b	ea1f4b6502fdebc2bf87c7d5f7dfdacb0c3a92d248fdfc002b524ccddea20c07	2023-01-19 13:27:59.939897+05:30	20230119075759_init	\N	\N	2023-01-19 13:27:59.934723+05:30	1
92a0219c-5fd7-410d-9a2a-7905862a1bd3	379d590dbfbc029b9b8c595dadab91bdcbcec2017e5d33ecede9f69a6dea0c0b	2023-01-20 10:37:26.047732+05:30	20230120050725_init	\N	\N	2023-01-20 10:37:26.03979+05:30	1
95b98c8a-da12-4d5a-9010-72e11edd4b5a	6d58f2cbaffa94dc883e7da9435900fd10b51bf840343db8afe9554712387b5d	2023-01-27 12:11:00.813528+05:30	20230127064100_init	\N	\N	2023-01-27 12:11:00.797383+05:30	1
be48194b-0cdb-450a-bea3-3ec6301467e9	3f44c07fca08e16731f9a7f5b8e87066a43203fccae12ad8ce6142cffcac8d4f	2023-03-01 14:38:08.168737+05:30	20230301090808_init	\N	\N	2023-03-01 14:38:08.161651+05:30	1
99e2fc7c-4d1b-40d7-9c42-7aae8ffe6378	9ffeed63e1c73cd80f1b48357793781f20643b5a3efde0eede0bf318f10ebf7d	2023-01-30 07:09:35.50726+05:30	20230130013935_init	\N	\N	2023-01-30 07:09:35.478592+05:30	1
4e3b917c-1574-4cf7-a93b-fb7b55134370	69a54690f312cf9e33dd8544afd139f00036cbaf003aa3028964c2be7650123c	2023-02-02 13:49:24.641828+05:30	20230202081924_init	\N	\N	2023-02-02 13:49:24.636029+05:30	1
508f26a9-178a-47c0-8ff5-b2ea393b399e	659ac5edc53586ffdaeb96106c0883cf0eb19e2e9700c688d6831fdf99a94cbe	2023-01-30 08:14:23.8379+05:30	20230130024423_init	\N	\N	2023-01-30 08:14:23.832515+05:30	1
8ade574e-45de-48ad-be94-0142e5ac4614	f441838d7ed30d5855f77b68485c3ce1df04bc7f14cdf7580d6a26779178b455	2023-02-20 01:18:19.473204+05:30	20230219194819_init	\N	\N	2023-02-20 01:18:19.467192+05:30	1
e84b4279-8266-43f9-8fe3-129e5d01dd6d	c96b221d8da5e722e6027f8043b84b79a58d2ae4196f1a4cf36fdc4619e9af8e	2023-02-13 13:00:42.455709+05:30	20230213073042_init	\N	\N	2023-02-13 13:00:42.450297+05:30	1
eb1adc90-5b82-4143-a8e4-0997b4350693	0566594b863e299bbfa3350372d670c3d02ed1b3d66ecc1b1ed0c2cf73592d3e	2023-02-17 15:07:59.050292+05:30	20230217093758_init	\N	\N	2023-02-17 15:07:59.031163+05:30	1
f3e5fc61-759d-4e77-bf08-8bc295a1012c	39bd150e110bc23fcbbddfb222dc23abe631c2ed342f0153c5cb270a2b628274	2023-02-27 11:44:53.201998+05:30	20230227061453_init	\N	\N	2023-02-27 11:44:53.194714+05:30	1
7df2da1f-6ab7-44f6-a298-1d06e13c42d0	be13027b39a1193d3b8f781d1f26c970cc7299d56486327299cf40775505d921	2023-03-03 18:36:54.009341+05:30	20230303130653_init	\N	\N	2023-03-03 18:36:53.996741+05:30	1
e3348cd1-fe96-4f6a-9d0d-0b5611e468a1	ff7d22da0cbdf774f84769d54f466232a74859ecd8f7d7c7bfa821d83a038433	2023-03-02 18:11:24.848985+05:30	20230302124124_init	\N	\N	2023-03-02 18:11:24.827455+05:30	1
fa6217cd-51b2-46e9-a3f9-140cf0298852	88662accd88a23aab12e888d942eebc64b9eef1d094f3bf3163bc797e038b761	2023-03-06 07:44:37.514289+05:30	20230306021437_init	\N	\N	2023-03-06 07:44:37.501234+05:30	1
26e9e421-87db-44b4-9f14-4951786b6b4d	89fc6e10c40c68add1f9d8984946c4f79552623f27d1c04f0bb0185ca3a0fa7c	2023-03-10 01:12:38.568981+05:30	20230309194238_init	\N	\N	2023-03-10 01:12:38.56375+05:30	1
d2d8519f-bf74-482c-8d51-fea845eddf6e	e3627d689268820415cde410bd53153d9a2051801904a9ad7c6e3be54184ef48	2023-03-14 12:23:44.670397+05:30	20230314065344_init	\N	\N	2023-03-14 12:23:44.66288+05:30	1
4011e6fa-c7f3-45ae-9bae-ee46013a130f	4bd1923bc9590f4a36d5b9ad76f09ef27943b40dc457099466447bb02849b46e	2023-03-17 11:30:40.856407+05:30	20230317060040_init	\N	\N	2023-03-17 11:30:40.842736+05:30	1
05c354ae-7645-4ae0-8646-3ec533ad1985	c58200862bd5df8af3de8e1e4b9f7790b72fbc056ca11fb7094230fcc31a9a0a	2023-03-22 17:30:15.708382+05:30	20230322120015_init	\N	\N	2023-03-22 17:30:15.701829+05:30	1
49de3164-cf61-4143-91cf-bc2a8b317192	90ec76d7982ced84879dc324ee4293a423f3758f814ee00f670e75ba5480433b	2023-03-24 16:18:28.220321+05:30	20230324104828_init	\N	\N	2023-03-24 16:18:28.185489+05:30	1
806b5ea0-7588-43fa-aa7c-d0e91d4dcbf1	cf08101fe0ac289ad99f2f9bcc34bae2d604744cfe72c82e23c84c22c3615fa5	2023-04-20 17:22:38.080998+05:30	20230420115238_init	\N	\N	2023-04-20 17:22:38.070933+05:30	1
48afcf01-6506-491b-be1e-7d620b592de7	870350ef8503c8ad9bd7a00c61b72aeaa56f1f43c40c37ec9ba2661375d71439	2023-04-21 13:16:45.019287+05:30	20230421074644_init	\N	\N	2023-04-21 13:16:44.990317+05:30	1
2bd734d5-6dff-4bf1-b3ca-270d5d5599a1	a28d2e1eb6f1e2b6af8cfc410e794996c93d95fac2db19ac20b9c8a90ce12fc2	2023-04-28 13:19:40.928724+05:30	20230428074940_init	\N	\N	2023-04-28 13:19:40.917663+05:30	1
\.


--
-- Data for Name: audience; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox.audience (audience_id, brand_id, created_at, updated_at) FROM stdin;
13	12	2023-02-02 08:36:09.957	2023-02-02 08:36:09.957
14	12	2023-02-03 08:52:03.716	2023-02-03 08:52:03.716
15	13	2023-04-03 09:33:41.664	2023-04-03 09:33:41.664
\.


--
-- Data for Name: audience_fields; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox.audience_fields (field_id, audience_id, field_name, field_value, created_at, updated_at, is_mandatory) FROM stdin;
35	13	approx_mau	"14500"	2023-02-02 08:36:09.965	2023-02-02 08:36:09.965	f
31	13	audience_group	"Shoppers"	2023-02-02 08:36:09.965	2023-02-02 08:36:09.965	f
37	13	audience_location	["Thailand", "India", "Indonesia"]	2023-02-02 08:36:09.965	2023-02-02 08:36:09.965	f
38	13	languages	["English", "Indian", "Thai"]	2023-02-02 08:36:09.965	2023-02-02 08:36:09.965	f
32	13	age_range_min	"18"	2023-02-02 08:36:09.965	2023-02-02 08:36:09.965	f
33	13	age_range_max	"25"	2023-02-02 08:36:09.965	2023-02-02 08:36:09.965	f
36	13	arpu	"1200-1500"	2023-02-02 08:36:09.965	2023-02-02 08:36:09.965	f
34	13	gender	["F"]	2023-02-02 08:36:09.965	2023-02-02 08:36:09.965	t
43	14	arpu	"1200-1500"	2023-02-03 08:52:03.723	2023-02-03 08:52:03.723	f
39	14	audience_group	"Shoppers"	2023-02-03 08:52:03.723	2023-02-03 08:52:03.723	f
45	14	languages	["English", "Indian", "Thai"]	2023-02-03 08:52:03.723	2023-02-03 08:52:03.723	f
46	14	percentage	"25"	2023-02-03 08:52:03.723	2023-02-03 08:52:03.723	f
40	14	age_range_min	"18"	2023-02-03 08:52:03.723	2023-02-03 08:52:03.723	t
42	14	gender	"F"	2023-02-03 08:52:03.723	2023-02-03 08:52:03.723	f
41	14	age_range_max	"25"	2023-02-03 08:52:03.723	2023-02-03 08:52:03.723	t
44	14	audience_location	["Thailand", "India", "Indonesia"]	2023-02-03 08:52:03.723	2023-02-03 08:52:03.723	t
47	15	audience_group	"Hackers"	2023-04-03 09:33:41.67	2023-04-03 09:33:41.67	f
48	15	age_range_min	"18"	2023-04-03 09:33:41.67	2023-04-03 09:33:41.67	t
49	15	age_range_max	"45"	2023-04-03 09:33:41.67	2023-04-03 09:33:41.67	t
50	15	gender	["M"]	2023-04-03 09:33:41.67	2023-04-03 09:33:41.67	t
51	15	arpu	"1200-1500"	2023-04-03 09:33:41.67	2023-04-03 09:33:41.67	f
52	15	audience_location	["Thailand", "India", "Indonesia"]	2023-04-03 09:33:41.67	2023-04-03 09:33:41.67	f
53	15	languages	["English", "Indian", "Bahasa Indonesia", "Thai"]	2023-04-03 09:33:41.67	2023-04-03 09:33:41.67	t
54	15	percentage	100	2023-04-03 09:33:41.67	2023-04-03 09:33:41.67	f
\.


--
-- Data for Name: brand; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox.brand (brand_id, brand_name, website, business_entity_id, created_at, updated_at, about, audience_location, languages, logo, mau, online_store, site_category, social_media_handles) FROM stdin;
9	Zomato	zomato.in	6	2023-02-02 07:58:16.734	2023-02-02 07:58:16.734	\N	"[\\"India\\", \\"Thailand\\"]"	\N	/uploads/1675324696729-zomato.png	1500-2000	\N	["Food Delivery"]	"{\\"twitter\\": \\"twitter.com\\", \\"instagram\\": \\"instagram.com\\"}"
10	Amazon	amazon.in	4	2023-02-02 07:59:35.709	2023-02-02 07:59:35.709	\N	"[\\"India\\", \\"Thailand\\"]"	\N	/uploads/1675324775704-amazon.png	1500-2000	\N	["e-commerce"]	"{\\"twitter\\": \\"twitter.com\\", \\"instagram\\": \\"instagram.com\\"}"
11	Swiggy	swiggy.in	5	2023-02-02 08:00:25.709	2023-02-02 08:00:25.709	\N	"[\\"India\\", \\"Thailand\\"]"	\N	/uploads/1675324825704-Swiggy-logo.png	1500-2000	\N	["Food Delivery"]	"{\\"twitter\\": \\"twitter.com\\", \\"instagram\\": \\"instagram.com\\"}"
12	Curly Tuktuk	fancytuktuk.in	2	2023-02-02 08:34:21.552	2023-02-02 08:34:21.552	\N	"[\\"India\\", \\"Dubai\\", \\"Qatar\\"]"	"[\\"Indian\\", \\"Bahasa Indonesia\\"]"	/uploads/1675326861533-xvWejEyc.jpg	1000-1500	\N	["Fashion", "e-commerce"]	"{\\"twitter\\": \\"twitter.com\\", \\"instagram\\": \\"instagram.com\\"}"
13	Jurassic Hack	jurassic.in	9	2023-04-03 09:31:38.349	2023-04-03 09:31:38.349	\N	"[\\"India\\", \\"Indonesia\\"]"	"[\\"Indian\\", \\"Thai\\"]"	/uploads/1680514298330-jurassic-park.jpg	1500-2000	\N	["Fashion", "e-commerce"]	"{\\"twitter\\": \\"twitter.com\\", \\"instagram\\": \\"instagram.com\\"}"
\.


--
-- Data for Name: campaign; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox.campaign (campaign_id, brand_id, audience_id, created_at, updated_at, status, preview_image) FROM stdin;
18	12	14	2023-03-14 08:48:27.723	2023-03-14 08:48:27.723	CREATED	\N
19	12	14	2023-03-14 08:57:33.396	2023-03-14 08:57:33.396	REQUESTED	\N
21	12	14	2023-03-24 11:04:34.638	2023-03-24 11:04:34.638	CREATED	/uploads/1679655874619-joker.jpg
23	13	15	2023-04-05 07:52:33.067	2023-04-05 07:52:33.067	OFFER_ACCEPTED	
\.


--
-- Data for Name: campaign_fields; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox.campaign_fields (field_id, campaign_id, field_name, field_value, created_at, updated_at) FROM stdin;
82	18	campaign_name	"Shein Sale"	2023-03-14 08:48:27.73	2023-03-14 08:48:27.73
83	18	about	"This campaign for targeting the fashionistas"	2023-03-14 08:48:27.73	2023-03-14 08:48:27.73
84	18	destination_url	"www.shein.com"	2023-03-14 08:48:27.73	2023-03-14 08:48:27.73
85	18	start_duration	"2023-02-01T09:58:07.915Z"	2023-03-14 08:48:27.73	2023-03-14 08:48:27.73
86	18	end_duration	"2023-02-02T09:58:07.915Z"	2023-03-14 08:48:27.73	2023-03-14 08:48:27.73
87	18	volume	"20000"	2023-03-14 08:48:27.73	2023-03-14 08:48:27.73
88	18	budget_min	"2000"	2023-03-14 08:48:27.73	2023-03-14 08:48:27.73
89	18	budget_max	"5000"	2023-03-14 08:48:27.73	2023-03-14 08:48:27.73
90	18	mau	"30000"	2023-03-14 08:48:27.73	2023-03-14 08:48:27.73
91	18	category	["ecommerce", "Shopping"]	2023-03-14 08:48:27.73	2023-03-14 08:48:27.73
92	18	creatives	[{"link": "https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885_960_720.jpg", "size": "200KB", "format": "jpg", "banner_type": "image"}]	2023-03-14 08:48:27.73	2023-03-14 08:48:27.73
93	19	campaign_name	"Sneakers Sale"	2023-03-14 08:57:33.411	2023-03-14 08:57:33.411
94	19	about	"This campaign for targeting the sneaker heads"	2023-03-14 08:57:33.411	2023-03-14 08:57:33.411
95	19	destination_url	"www.nike.com"	2023-03-14 08:57:33.411	2023-03-14 08:57:33.411
96	19	start_duration	"2023-02-01T09:58:07.915Z"	2023-03-14 08:57:33.411	2023-03-14 08:57:33.411
97	19	end_duration	"2023-02-02T09:58:07.915Z"	2023-03-14 08:57:33.411	2023-03-14 08:57:33.411
98	19	volume	"20000"	2023-03-14 08:57:33.411	2023-03-14 08:57:33.411
99	19	budget_min	"2000"	2023-03-14 08:57:33.411	2023-03-14 08:57:33.411
100	19	budget_max	"5000"	2023-03-14 08:57:33.411	2023-03-14 08:57:33.411
101	19	mau	"30000"	2023-03-14 08:57:33.411	2023-03-14 08:57:33.411
102	19	category	["ecommerce", "Shopping"]	2023-03-14 08:57:33.411	2023-03-14 08:57:33.411
103	19	creatives	[{"link": "https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885_960_720.jpg", "size": "200KB", "format": "jpg", "banner_type": "image"}]	2023-03-14 08:57:33.411	2023-03-14 08:57:33.411
104	21	campaign_name	"Iphone Sale"	2023-03-24 11:04:34.649	2023-03-24 11:04:34.649
105	21	about	"This campaign for targeting the Apple lovers"	2023-03-24 11:04:34.649	2023-03-24 11:04:34.649
106	21	destination_url	"www.apple.com"	2023-03-24 11:04:34.649	2023-03-24 11:04:34.649
107	21	start_duration	"2023-03-24T09:58:07.915Z"	2023-03-24 11:04:34.649	2023-03-24 11:04:34.649
108	21	end_duration	"2023-03-25T09:58:07.915Z"	2023-03-24 11:04:34.649	2023-03-24 11:04:34.649
109	21	volume	"20000"	2023-03-24 11:04:34.649	2023-03-24 11:04:34.649
110	21	budget_min	"2000"	2023-03-24 11:04:34.649	2023-03-24 11:04:34.649
111	21	budget_max	"5000"	2023-03-24 11:04:34.649	2023-03-24 11:04:34.649
112	21	mau	"30000"	2023-03-24 11:04:34.649	2023-03-24 11:04:34.649
113	21	category	["ecommerce", "Shopping"]	2023-03-24 11:04:34.649	2023-03-24 11:04:34.649
124	23	campaign_name	"Hackers Sale"	2023-04-05 07:52:33.076	2023-04-05 07:52:33.076
125	23	about	"This campaign for targeting the hackathon lovers"	2023-04-05 07:52:33.076	2023-04-05 07:52:33.076
126	23	destination_url	"www.jurassichack.in"	2023-04-05 07:52:33.076	2023-04-05 07:52:33.076
127	23	start_duration	"2023-04-07T09:58:07.915Z"	2023-04-05 07:52:33.076	2023-04-05 07:52:33.076
128	23	end_duration	"2023-04-10T09:58:07.915Z"	2023-04-05 07:52:33.076	2023-04-05 07:52:33.076
129	23	volume	"20000"	2023-04-05 07:52:33.076	2023-04-05 07:52:33.076
130	23	budget_min	"2000"	2023-04-05 07:52:33.076	2023-04-05 07:52:33.076
131	23	budget_max	"5000"	2023-04-05 07:52:33.076	2023-04-05 07:52:33.076
132	23	mau	"30000"	2023-04-05 07:52:33.076	2023-04-05 07:52:33.076
133	23	category	["Technology", "Shopping"]	2023-04-05 07:52:33.076	2023-04-05 07:52:33.076
\.


--
-- Data for Name: location; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox.location (location_id, location_name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permission; Type: TABLE DATA; Schema: mox; Owner: postgres
--

COPY mox.permission (permission_id, permission_name, created_at, updated_at) FROM stdin;
\.


--
-- Name: BusinessCategories_business_category_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox."BusinessCategories_business_category_id_seq"', 40, true);


--
-- Name: BusinessEntityType_business_entity_type_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox."BusinessEntityType_business_entity_type_id_seq"', 3, true);


--
-- Name: BusinessEntity_business_entity_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox."BusinessEntity_business_entity_id_seq"', 9, true);


--
-- Name: CampaignCreatives_creative_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox."CampaignCreatives_creative_id_seq"', 2, true);


--
-- Name: ClientDBInfo_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox."ClientDBInfo_id_seq"', 12, true);


--
-- Name: ConnectionRequest_request_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox."ConnectionRequest_request_id_seq"', 14, true);


--
-- Name: CountriesData_country_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox."CountriesData_country_id_seq"', 79, true);


--
-- Name: DataProof_proof_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox."DataProof_proof_id_seq"', 16, true);


--
-- Name: FieldMapping_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox."FieldMapping_id_seq"', 7, true);


--
-- Name: Languages_language_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox."Languages_language_id_seq"', 24, true);


--
-- Name: Module_module_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox."Module_module_id_seq"', 1, false);


--
-- Name: RoleModule_role_module_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox."RoleModule_role_module_id_seq"', 1, false);


--
-- Name: Role_user_role_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox."Role_user_role_id_seq"', 1, false);


--
-- Name: UserAccountRole_user_account_role_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox."UserAccountRole_user_account_role_id_seq"', 1, false);


--
-- Name: UserAccount_user_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox."UserAccount_user_id_seq"', 9, true);


--
-- Name: UserPids_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox."UserPids_id_seq"', 84, true);


--
-- Name: audience_audience_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox.audience_audience_id_seq', 15, true);


--
-- Name: audience_fields_field_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox.audience_fields_field_id_seq', 54, true);


--
-- Name: brand_brand_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox.brand_brand_id_seq', 13, true);


--
-- Name: campaign_campaign_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox.campaign_campaign_id_seq', 23, true);


--
-- Name: campaign_fields_field_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox.campaign_fields_field_id_seq', 133, true);


--
-- Name: location_location_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox.location_location_id_seq', 1, false);


--
-- Name: permission_permission_id_seq; Type: SEQUENCE SET; Schema: mox; Owner: postgres
--

SELECT pg_catalog.setval('mox.permission_permission_id_seq', 1, false);


--
-- Name: BusinessCategories BusinessCategories_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."BusinessCategories"
    ADD CONSTRAINT "BusinessCategories_pkey" PRIMARY KEY (business_category_id);


--
-- Name: BusinessEntityType BusinessEntityType_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."BusinessEntityType"
    ADD CONSTRAINT "BusinessEntityType_pkey" PRIMARY KEY (business_entity_type_id);


--
-- Name: BusinessEntity BusinessEntity_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."BusinessEntity"
    ADD CONSTRAINT "BusinessEntity_pkey" PRIMARY KEY (business_entity_id);


--
-- Name: CampaignCreatives CampaignCreatives_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."CampaignCreatives"
    ADD CONSTRAINT "CampaignCreatives_pkey" PRIMARY KEY (creative_id);


--
-- Name: ClientDBInfo ClientDBInfo_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."ClientDBInfo"
    ADD CONSTRAINT "ClientDBInfo_pkey" PRIMARY KEY (id);


--
-- Name: ConnectionRequest ConnectionRequest_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."ConnectionRequest"
    ADD CONSTRAINT "ConnectionRequest_pkey" PRIMARY KEY (request_id);


--
-- Name: CountriesData CountriesData_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."CountriesData"
    ADD CONSTRAINT "CountriesData_pkey" PRIMARY KEY (country_id);


--
-- Name: DataProof DataProof_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."DataProof"
    ADD CONSTRAINT "DataProof_pkey" PRIMARY KEY (proof_id);


--
-- Name: FieldMapping FieldMapping_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."FieldMapping"
    ADD CONSTRAINT "FieldMapping_pkey" PRIMARY KEY (id);


--
-- Name: Languages Languages_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."Languages"
    ADD CONSTRAINT "Languages_pkey" PRIMARY KEY (language_id);


--
-- Name: Module Module_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."Module"
    ADD CONSTRAINT "Module_pkey" PRIMARY KEY (module_id);


--
-- Name: RoleModule RoleModule_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."RoleModule"
    ADD CONSTRAINT "RoleModule_pkey" PRIMARY KEY (role_module_id);


--
-- Name: Role Role_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."Role"
    ADD CONSTRAINT "Role_pkey" PRIMARY KEY (user_role_id);


--
-- Name: UserAccountRole UserAccountRole_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."UserAccountRole"
    ADD CONSTRAINT "UserAccountRole_pkey" PRIMARY KEY (user_account_role_id);


--
-- Name: UserAccount UserAccount_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."UserAccount"
    ADD CONSTRAINT "UserAccount_pkey" PRIMARY KEY (user_id);


--
-- Name: UserPids UserPids_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."UserPids"
    ADD CONSTRAINT "UserPids_pkey" PRIMARY KEY (id);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: audience_fields audience_fields_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.audience_fields
    ADD CONSTRAINT audience_fields_pkey PRIMARY KEY (field_id);


--
-- Name: audience audience_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.audience
    ADD CONSTRAINT audience_pkey PRIMARY KEY (audience_id);


--
-- Name: brand brand_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.brand
    ADD CONSTRAINT brand_pkey PRIMARY KEY (brand_id);


--
-- Name: campaign_fields campaign_fields_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.campaign_fields
    ADD CONSTRAINT campaign_fields_pkey PRIMARY KEY (field_id);


--
-- Name: campaign campaign_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.campaign
    ADD CONSTRAINT campaign_pkey PRIMARY KEY (campaign_id);


--
-- Name: location location_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.location
    ADD CONSTRAINT location_pkey PRIMARY KEY (location_id);


--
-- Name: permission permission_pkey; Type: CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.permission
    ADD CONSTRAINT permission_pkey PRIMARY KEY (permission_id);


--
-- Name: ClientDBInfo_brand_id_key; Type: INDEX; Schema: mox; Owner: postgres
--

CREATE UNIQUE INDEX "ClientDBInfo_brand_id_key" ON mox."ClientDBInfo" USING btree (brand_id);


--
-- Name: ClientDBInfo_business_entity_id_key; Type: INDEX; Schema: mox; Owner: postgres
--

CREATE UNIQUE INDEX "ClientDBInfo_business_entity_id_key" ON mox."ClientDBInfo" USING btree (business_entity_id);


--
-- Name: RoleModule_user_role_id_key; Type: INDEX; Schema: mox; Owner: postgres
--

CREATE UNIQUE INDEX "RoleModule_user_role_id_key" ON mox."RoleModule" USING btree (user_role_id);


--
-- Name: UserAccountRole_user_id_key; Type: INDEX; Schema: mox; Owner: postgres
--

CREATE UNIQUE INDEX "UserAccountRole_user_id_key" ON mox."UserAccountRole" USING btree (user_id);


--
-- Name: BusinessEntity BusinessEntity_business_entity_type_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."BusinessEntity"
    ADD CONSTRAINT "BusinessEntity_business_entity_type_id_fkey" FOREIGN KEY (business_entity_type_id) REFERENCES mox."BusinessEntityType"(business_entity_type_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: CampaignCreatives CampaignCreatives_campaign_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."CampaignCreatives"
    ADD CONSTRAINT "CampaignCreatives_campaign_id_fkey" FOREIGN KEY (campaign_id) REFERENCES mox.campaign(campaign_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ClientDBInfo ClientDBInfo_brand_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."ClientDBInfo"
    ADD CONSTRAINT "ClientDBInfo_brand_id_fkey" FOREIGN KEY (brand_id) REFERENCES mox.brand(brand_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ClientDBInfo ClientDBInfo_business_entity_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."ClientDBInfo"
    ADD CONSTRAINT "ClientDBInfo_business_entity_id_fkey" FOREIGN KEY (business_entity_id) REFERENCES mox."BusinessEntity"(business_entity_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ConnectionRequest ConnectionRequest_receiver_brandId_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."ConnectionRequest"
    ADD CONSTRAINT "ConnectionRequest_receiver_brandId_fkey" FOREIGN KEY ("receiver_brandId") REFERENCES mox.brand(brand_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ConnectionRequest ConnectionRequest_receiver_userId_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."ConnectionRequest"
    ADD CONSTRAINT "ConnectionRequest_receiver_userId_fkey" FOREIGN KEY ("receiver_userId") REFERENCES mox."UserAccount"(user_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ConnectionRequest ConnectionRequest_sender_brandId_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."ConnectionRequest"
    ADD CONSTRAINT "ConnectionRequest_sender_brandId_fkey" FOREIGN KEY ("sender_brandId") REFERENCES mox.brand(brand_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ConnectionRequest ConnectionRequest_sender_campaignId_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."ConnectionRequest"
    ADD CONSTRAINT "ConnectionRequest_sender_campaignId_fkey" FOREIGN KEY ("sender_campaignId") REFERENCES mox.campaign(campaign_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: ConnectionRequest ConnectionRequest_sender_userId_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."ConnectionRequest"
    ADD CONSTRAINT "ConnectionRequest_sender_userId_fkey" FOREIGN KEY ("sender_userId") REFERENCES mox."UserAccount"(user_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DataProof DataProof_receiver_brand_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."DataProof"
    ADD CONSTRAINT "DataProof_receiver_brand_id_fkey" FOREIGN KEY (receiver_brand_id) REFERENCES mox.brand(brand_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DataProof DataProof_receiver_business_entity_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."DataProof"
    ADD CONSTRAINT "DataProof_receiver_business_entity_id_fkey" FOREIGN KEY (receiver_business_entity_id) REFERENCES mox."BusinessEntity"(business_entity_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DataProof DataProof_sender_brand_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."DataProof"
    ADD CONSTRAINT "DataProof_sender_brand_id_fkey" FOREIGN KEY (sender_brand_id) REFERENCES mox.brand(brand_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DataProof DataProof_sender_business_entity_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."DataProof"
    ADD CONSTRAINT "DataProof_sender_business_entity_id_fkey" FOREIGN KEY (sender_business_entity_id) REFERENCES mox."BusinessEntity"(business_entity_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: DataProof DataProof_sender_campaign_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."DataProof"
    ADD CONSTRAINT "DataProof_sender_campaign_id_fkey" FOREIGN KEY (sender_campaign_id) REFERENCES mox.campaign(campaign_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RoleModule RoleModule_module_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."RoleModule"
    ADD CONSTRAINT "RoleModule_module_id_fkey" FOREIGN KEY (module_id) REFERENCES mox."Module"(module_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: RoleModule RoleModule_user_role_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."RoleModule"
    ADD CONSTRAINT "RoleModule_user_role_id_fkey" FOREIGN KEY (user_role_id) REFERENCES mox."Role"(user_role_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserAccountRole UserAccountRole_user_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."UserAccountRole"
    ADD CONSTRAINT "UserAccountRole_user_id_fkey" FOREIGN KEY (user_id) REFERENCES mox."UserAccount"(user_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserAccountRole UserAccountRole_user_role_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."UserAccountRole"
    ADD CONSTRAINT "UserAccountRole_user_role_id_fkey" FOREIGN KEY (user_role_id) REFERENCES mox."Role"(user_role_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserAccount UserAccount_business_entity_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."UserAccount"
    ADD CONSTRAINT "UserAccount_business_entity_id_fkey" FOREIGN KEY (business_entity_id) REFERENCES mox."BusinessEntity"(business_entity_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserPids UserPids_receiver_brand_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."UserPids"
    ADD CONSTRAINT "UserPids_receiver_brand_id_fkey" FOREIGN KEY (receiver_brand_id) REFERENCES mox.brand(brand_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserPids UserPids_receiver_business_entity_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."UserPids"
    ADD CONSTRAINT "UserPids_receiver_business_entity_id_fkey" FOREIGN KEY (receiver_business_entity_id) REFERENCES mox."BusinessEntity"(business_entity_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserPids UserPids_sender_brand_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."UserPids"
    ADD CONSTRAINT "UserPids_sender_brand_id_fkey" FOREIGN KEY (sender_brand_id) REFERENCES mox.brand(brand_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserPids UserPids_sender_business_entity_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."UserPids"
    ADD CONSTRAINT "UserPids_sender_business_entity_id_fkey" FOREIGN KEY (sender_business_entity_id) REFERENCES mox."BusinessEntity"(business_entity_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: UserPids UserPids_sender_campaign_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox."UserPids"
    ADD CONSTRAINT "UserPids_sender_campaign_id_fkey" FOREIGN KEY (sender_campaign_id) REFERENCES mox.campaign(campaign_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: audience audience_brand_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.audience
    ADD CONSTRAINT audience_brand_id_fkey FOREIGN KEY (brand_id) REFERENCES mox.brand(brand_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: audience_fields audience_fields_audience_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.audience_fields
    ADD CONSTRAINT audience_fields_audience_id_fkey FOREIGN KEY (audience_id) REFERENCES mox.audience(audience_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: brand brand_business_entity_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.brand
    ADD CONSTRAINT brand_business_entity_id_fkey FOREIGN KEY (business_entity_id) REFERENCES mox."BusinessEntity"(business_entity_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: campaign campaign_audience_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.campaign
    ADD CONSTRAINT campaign_audience_id_fkey FOREIGN KEY (audience_id) REFERENCES mox.audience(audience_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: campaign campaign_brand_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.campaign
    ADD CONSTRAINT campaign_brand_id_fkey FOREIGN KEY (brand_id) REFERENCES mox.brand(brand_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: campaign_fields campaign_fields_campaign_id_fkey; Type: FK CONSTRAINT; Schema: mox; Owner: postgres
--

ALTER TABLE ONLY mox.campaign_fields
    ADD CONSTRAINT campaign_fields_campaign_id_fkey FOREIGN KEY (campaign_id) REFERENCES mox.campaign(campaign_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

